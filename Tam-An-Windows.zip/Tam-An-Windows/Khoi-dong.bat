@echo off
setlocal
cd /d "%~dp0"
title Tam An Live Studio
if exist "runtime\node.exe" (
  "runtime\node.exe" "scripts\start-windows.cjs"
  if errorlevel 1 (
    pause
    exit /b 1
  )
  exit /b 0
)
where node >nul 2>nul
if errorlevel 1 (
  echo Ban dang mo bo MA NGUON. Hay tai bo TAM AN WINDOWS da dong goi san.
  echo Neu muon chay ma nguon, cai Node.js 24 LTS tu https://nodejs.org.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Dang cai thu vien. Vui long cho...
  call npm ci --no-audit --no-fund
  if errorlevel 1 goto failed
)
call npm run build
if errorlevel 1 goto failed
node "scripts\start-windows.cjs"
if errorlevel 1 (
  pause
  exit /b 1
)
exit /b 0
:failed
echo Khong khoi dong duoc. Vui long gui noi dung loi trong cua so nay de kiem tra.
pause
exit /b 1
