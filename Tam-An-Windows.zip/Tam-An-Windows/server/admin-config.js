import { CHANTS } from './audio-config.js';

export const DEFAULT_BLESSINGS = [
  'Chúc bạn và gia đình luôn bình an, thân tâm an lạc, mọi việc thuận duyên.',
  'Nguyện những điều tốt lành đến với bạn, sức khỏe dồi dào, nụ cười luôn ở lại.',
  'Chúc bạn một đời an nhiên, đi qua khó khăn bằng trái tim vững vàng.',
  'Nguyện gia đình bạn hòa thuận, yêu thương và hạnh phúc mỗi ngày.',
  'Chúc bạn công việc hanh thông, gặp người tử tế và có nhiều duyên lành.',
  'Nguyện cho tâm bạn nhẹ nhàng, buông xuống muộn phiền và đón nhận bình yên.',
  'Chúc những mong ước thiện lành của bạn sớm thành hiện thực.',
  'Nguyện bạn luôn đủ sức khỏe, đủ niềm tin và đủ yêu thương trên mọi chặng đường.',
  'Chúc bạn hôm nay an vui, ngày mai tươi sáng và mỗi ngày đều có điều đáng biết ơn.',
  'Nguyện phúc lành đến với bạn, nhà nhà ấm áp, người người bình an.',
  'Chúc bạn tìm thấy niềm vui trong những điều giản dị và sự an lạc trong chính mình.',
  'Nguyện mọi nỗ lực chân thành của bạn đều nở hoa, mọi bước chân đều gặp thuận duyên.',
];

export const INTENT_RULES = [
  { field: 'wishEducation', words: ['thi cu', 'thi tot', 'thi dau', 'thi do', 'diem cao', 'hoc tap', 'dai hoc', 'tot nghiep', 'hoc sinh', 'bai thi'], text: 'Chúc bạn học tập vững vàng, giữ tâm bình tĩnh, tự tin làm bài và đạt kết quả xứng đáng với công sức của mình.' },
  { field: 'wishHealth', words: ['suc khoe', 'benh', 'khoi', 'phau thuat', 'dieu tri', 'ung thu', 'benh vien'], text: 'Chúc bạn và người thân sức khỏe dồi dào, tinh thần vững vàng, sớm vượt qua những ngày khó khăn và luôn được chăm sóc chu đáo.' },
  { field: 'wishLove', words: ['tinh duyen', 'tinh yeu', 'nguoi yeu', 'ket hon', 'vo chong', 'hon nhan', 'chia tay'], text: 'Chúc đường tình duyên của bạn gặp nhiều duyên lành, được yêu thương chân thành, biết lắng nghe và cùng nhau vun đắp hạnh phúc.' },
  { field: 'wishFamily', words: ['gia dinh', 'cha me', 'ba me', 'bo me', 'ong ba', 'con cai', 'con chau', 'gia dao'], text: 'Chúc gia đình bạn luôn khỏe mạnh, hòa thuận, biết yêu thương và gìn giữ những phút giây sum vầy.' },
  { field: 'wishWork', words: ['cong viec', 'viec lam', 'kinh doanh', 'buon ban', 'lam an', 'tai loc', 'su nghiep', 'phong van'], text: 'Chúc công việc của bạn thuận lợi, kinh doanh chân chính, gặp người đồng hành tốt và gặt hái thành quả từ sự nỗ lực.' },
  { field: 'wishPeace', words: ['binh an', 'an lanh', 'an lac', 'hanh phuc', 'muon phien', 'buon', 'lo lang'], text: 'Chúc bạn tâm an, lòng nhẹ, vững vàng trước những điều chưa như ý và tìm thấy niềm vui trong từng ngày.' },
];

export const ADMIN_DEFAULTS = {
  walkSpeed: 1, returnSpeed: 1, incenseDuration: 1.5, bowCount: 3, bowDuration: 2, bowAngle: 66,
  ritualEnabled: true, incenseOnComment: true, incenseOnGift: true, incenseKeywords: ['adidaphat', 'A Di Đà Phật', 'Nam mô A Di Đà Phật'],
  blessings: DEFAULT_BLESSINGS, blessingMode: 'random', chantTexts: CHANTS,
  giftTemplate: '{kenh} xin cảm ơn {ten} đã gửi {soluong} {qua}. {loichuc}',
  joinTemplate: '{kenh} chào {ten}. Chúc bạn tâm an, mọi điều thuận duyên. Mời bạn an tọa.',
  incenseTemplate: '{kenh} kính chúc {ten} thân tâm an lạc, gia đạo bình an. A Di Đà Phật.',
  commentTemplate: '{kenh} gửi lời chúc đến {ten}. {loichuc}',
  genericCommentTemplate: '{kenh} nhận được lời nhắn của {ten}: {binhluan}. {loichuc}',
  idleTemplate: '{kenh} gửi lời chúc an lành đến tất cả mọi người. {loichuc} Mời bạn chia sẻ buổi live để cùng lan tỏa những điều tốt đẹp.',
  lotusTemplate: '{kenh} cảm ơn những trái tim yêu thương. Xin gửi một cơn mưa hoa sen và lời chúc an lành đến tất cả mọi người.',
  idleSeconds: 90, heartThreshold: 666, lotusRainSeconds: 60, commentPoints: 1, giftPoints: 10,
  effectsEnabled: true, giftCameraEnabled: true, giftCameraZoom: 1, goldenLotusEnabled: true, giftPetalsEnabled: true, ambientPetalsEnabled: true,
  petalCount: 90, petalFallSpeed: 1, characterScale: 1, maxVisibleViewers: 28, sceneBrightness: 1, giftCardSeconds: 6.5,
  showChannelInfo: true, showLeaderBoard: true, showOfferingGuide: true, showPrayerHint: true, showHeartProgress: true, showWatermark: true, showNameplates: true, showAvatars: true,
  stageTitle: 'Nguyện đời an nhiên', stageEyebrow: 'GỬI MỘT TẤM LÒNG', watermarkText: 'TÂM AN · MỘT NIỆM AN LÀNH',
  leaderboardTitle: 'TOP THÀNH TÂM', stageLeaderboardSize: 4, giftCardLabel: 'THÀNH TÂM CÔNG ĐỨC', giftCardBlessing: '🙏 Nguyện vạn sự an lành',
  ...Object.fromEntries(INTENT_RULES.map(rule => [rule.field, rule.text])),
};

export const ADMIN_NUMBERS = {
  walkSpeed: [.25, 4], returnSpeed: [.25, 4], incenseDuration: [.3, 15], bowCount: [0, 108], bowDuration: [.4, 8], bowAngle: [15, 85],
  idleSeconds: [15, 600], heartThreshold: [1, 100000], lotusRainSeconds: [1, 300], commentPoints: [0, 100], giftPoints: [0, 1000],
  giftCameraZoom: [0, 1], petalCount: [0, 200], petalFallSpeed: [.25, 3], characterScale: [.6, 1.6], maxVisibleViewers: [4, 40],
  sceneBrightness: [.4, 1.8], giftCardSeconds: [1, 30], stageLeaderboardSize: [1, 10],
};
export const ADMIN_BOOLEANS = ['ritualEnabled','incenseOnComment','incenseOnGift','effectsEnabled','giftCameraEnabled','goldenLotusEnabled','giftPetalsEnabled','ambientPetalsEnabled','showChannelInfo','showLeaderBoard','showOfferingGuide','showPrayerHint','showHeartProgress','showWatermark','showNameplates','showAvatars'];
export const ADMIN_TEXT = ['giftTemplate','joinTemplate','incenseTemplate','commentTemplate','genericCommentTemplate','idleTemplate','lotusTemplate','wishEducation','wishHealth','wishLove','wishFamily','wishWork','wishPeace','stageTitle','stageEyebrow','watermarkText','leaderboardTitle','giftCardLabel','giftCardBlessing'];
const INTEGERS = new Set(['bowCount','heartThreshold','lotusRainSeconds','petalCount','maxVisibleViewers','stageLeaderboardSize']);
export function adminSettings(input, next) {
  for (const [name,[low,high]] of Object.entries(ADMIN_NUMBERS)) {
    if (input[name] !== undefined && input[name] !== null && Number.isFinite(Number(input[name]))) {
      const value = Math.max(low,Math.min(high,Number(input[name]))); next[name] = INTEGERS.has(name) ? Math.round(value) : value;
    }
  }
  for (const name of ADMIN_BOOLEANS) if (typeof input[name] === 'boolean') next[name] = input[name];
  for (const name of ADMIN_TEXT) if (typeof input[name] === 'string') next[name] = input[name].replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,name.endsWith('Template')?800:300);
  for (const name of ['blessings','chantTexts','incenseKeywords']) if (Array.isArray(input[name])) next[name] = input[name].filter(item=>typeof item==='string').slice(0,name==='incenseKeywords'?10:60).map(item=>item.replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,name==='incenseKeywords'?50:400)).filter(Boolean);
  if (['random','ordered'].includes(input.blessingMode)) next.blessingMode = input.blessingMode;
  return next;
}
export function ritualSnapshot(settings) {
  return Object.fromEntries(['walkSpeed','returnSpeed','incenseDuration','bowCount','bowDuration','bowAngle'].map(name=>[name,settings[name]]));
}
export function renderTemplate(template, values = {}) {
  return String(template).replace(/\{([a-z_]+)\}/g,(match,key)=>values[key]===undefined?match:String(values[key])).replace(/\s+/g,' ').trim().slice(0,500);
}
