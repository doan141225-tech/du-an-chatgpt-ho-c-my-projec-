import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';
import { AUDIO_PRESET, EDGE_VOICES } from './audio-config.js';
import { ADMIN_DEFAULTS, INTENT_RULES, adminSettings, ritualSnapshot, renderTemplate } from './admin-config.js';

export const DEFAULT_SETTINGS = Object.freeze({
  channelName: 'Tâm An Lành', tiktokUsername: 'yahyah_155', voiceEnabled: true,
  readComments: true, greetViewers: true, idleBlessings: true,
  volume: 0.85, demoMode: true, ...AUDIO_PRESET, ...ADMIN_DEFAULTS,
});

export { DEFAULT_BLESSINGS as BLESSINGS } from './admin-config.js';

export function normalizeText(value) {
  return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().replace(/\s+/g, ' ').trim();
}

function boundedText(value, max = 300) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

export function safeAvatar(value) {
  if (typeof value !== 'string' || value.length > 2048) return '';
  if (/^\/api\/avatar\/[a-z0-9_-]+(?:\?[^\s]*)?$/i.test(value)) return value;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
  } catch { return ''; }
}

export function sanitizeUser(input = {}) {
  input = input.user || input;
  const id = boundedText(input.id || input.uniqueId || input.userId || input.nickname || 'khach', 100);
  const nickname = boundedText(input.nickname || input.uniqueId || 'Bạn hữu duyên', 60);
  const rawAvatar = input.avatar || input.profilePictureUrl || input.profilePicture?.url?.[0] || '';
  return { id, nickname, avatar: safeAvatar(rawAvatar) };
}

export function commentBlessing(text, settings = DEFAULT_SETTINGS) {
  const normalized = normalizeText(text);
  const rule = INTENT_RULES.find(({words})=>words.some(word=>normalized.includes(word)));
  return rule ? settings[rule.field] : null;
}

export function isIncenseComment(text, keywords = DEFAULT_SETTINGS.incenseKeywords) {
  const compact = normalizeText(text).replace(/[^a-z0-9]/g, '');
  return keywords.some(keyword=>{const value=normalizeText(keyword).replace(/[^a-z0-9]/g,'');return value && compact.includes(value);});
}

export function sanitizeSettings(input = {}, existing = DEFAULT_SETTINGS) {
  const next = { ...existing };
  if (typeof input.channelName === 'string') next.channelName = boundedText(input.channelName, 60) || DEFAULT_SETTINGS.channelName;
  if (typeof input.tiktokUsername === 'string') next.tiktokUsername = input.tiktokUsername.replace(/^@/, '').replace(/[^a-zA-Z0-9_.]/g, '').slice(0, 64);
  for (const name of ['voiceEnabled', 'readComments', 'greetViewers', 'idleBlessings', 'demoMode', 'voiceFallback', 'musicEnabled', 'musicDuck', 'moEnabled', 'bellEnabled', 'autoChant']) {
    if (typeof input[name] === 'boolean') next[name] = input[name];
  }
  if (Number.isFinite(Number(input.volume))) next.volume = Math.max(0, Math.min(1, Number(input.volume)));
  const numeric = { rate: [0.5, 1.5], commentRate: [0.5, 1.5], pitch: [-50, 50], musicVolume: [0, 1], musicDuckLevel: [0, 1], musicCrossfade: [0, 8], moBpm: [20, 120], sfxVolume: [0, 1], chantEverySec: [15, 180] };
  for (const [name, [low, high]] of Object.entries(numeric)) {
    if (input[name] !== undefined && input[name] !== null && Number.isFinite(Number(input[name]))) next[name] = Math.max(low, Math.min(high, Number(input[name])));
  }
  if (['edge', 'browser', 'offline'].includes(input.voiceEngine)) next.voiceEngine = input.voiceEngine;
  if (EDGE_VOICES.includes(input.voice)) next.voice = input.voice;
  if (['cycle', 'music1', 'music2'].includes(input.musicMode)) next.musicMode = input.musicMode;
  if (typeof input.browserVoice === 'string') next.browserVoice = boundedText(input.browserVoice, 180);
  return adminSettings(input, next);
}

export const DEMO_USERS = [
  { id: 'minhan', nickname: 'Minh An', avatar: '/api/avatar/minhan?name=Minh%20An' },
  { id: 'thanhha', nickname: 'Thanh Hà', avatar: '/api/avatar/thanhha?name=Thanh%20H%C3%A0' },
  { id: 'ngoclinh', nickname: 'Ngọc Linh', avatar: '/api/avatar/ngoclinh?name=Ng%E1%BB%8Dc%20Linh' },
  { id: 'hoangnam', nickname: 'Hoàng Nam', avatar: '/api/avatar/hoangnam?name=Ho%C3%A0ng%20Nam' },
  { id: 'anhnhi', nickname: 'Anh Nhi', avatar: '/api/avatar/anhnhi?name=Anh%20Nhi' },
  { id: 'phucloc', nickname: 'Phúc Lộc', avatar: '/api/avatar/phucloc?name=Ph%C3%BAc%20L%E1%BB%99c' },
  { id: 'nhuy', nickname: 'Như Ý', avatar: '/api/avatar/nhuy?name=Nh%C6%B0%20%C3%9D' },
  { id: 'giabao', nickname: 'Gia Bảo', avatar: '/api/avatar/giabao?name=Gia%20B%E1%BA%A3o' },
];

export class LiveEngine extends EventEmitter {
  constructor(settings = {}, { now = Date.now, random = Math.random, seed = true } = {}) {
    super();
    this.now = now;
    this.random = random;
    this.settings = sanitizeSettings(settings);
    this.connection = { status: this.settings.demoMode ? 'demo' : 'disconnected', message: this.settings.demoMode ? 'Đang chạy chế độ trải nghiệm' : 'Chưa kết nối TikTok LIVE' };
    this.viewers = new Map();
    this.scores = new Map();
    this.events = [];
    this.ritualQueue = [];
    this.stats = { viewers: 0, gifts: 0, diamonds: 0, likes: 0, rituals: 0 };
    this.remoteViewerCount = null;
    this.lotusUntil = 0;
    this.lastActivity = this.now();
    this.lastIdle = this.now();
    this.lastBlessing = -1;
    this.chantIndex = 0;
    this.nextChant = this.now() + 4000;
    this.giftStreaks = new Map();
    this.seenGifts = new Set();
    if (seed && this.settings.demoMode) this.seedDemo();
  }

  seedDemo() {
    DEMO_USERS.forEach((user, index) => {
      this.viewers.set(user.id, { ...user, joinedAt: this.now(), seat: index });
      this.scores.set(user.id, { ...user, score: [328, 256, 186, 128, 98, 72, 56, 32][index], comments: [18, 16, 16, 18, 18, 12, 6, 2][index], diamonds: [31, 24, 17, 11, 8, 6, 5, 3][index], gifts: [12, 9, 8, 5, 4, 3, 2, 1][index] });
    });
    for (const score of this.scores.values()) score.score = score.comments * this.settings.commentPoints + score.diamonds * this.settings.giftPoints;
    this.stats.viewers = this.remoteViewerCount ?? this.viewers.size;
    this.stats.likes = 328;
  }

  getState() {
    return {
      settings: { ...this.settings }, connection: { ...this.connection },
      viewers: [...this.viewers.values()],
      leaderboard: [...this.scores.values()].sort((a, b) => b.score - a.score).slice(0, 30),
      stats: { ...this.stats }, events: [...this.events], ritualQueue: [...this.ritualQueue], lotusUntil: this.lotusUntil,
    };
  }

  changed() { this.emit('state', this.getState()); }

  setSettings(input) {
    const previous = this.settings;
    this.settings = sanitizeSettings(input, this.settings);
    if (previous.autoChant !== this.settings.autoChant || previous.chantEverySec !== this.settings.chantEverySec) this.nextChant = this.now() + 4000;
    if (this.settings.demoMode && ['disconnected', 'error', 'demo'].includes(this.connection.status)) {
      this.connection = { status: 'demo', message: 'Đang chạy chế độ trải nghiệm' };
    } else if (!this.settings.demoMode && this.connection.status === 'demo') {
      this.connection = { status: 'disconnected', message: 'Chưa kết nối TikTok LIVE' };
    }
    if (previous.commentPoints !== this.settings.commentPoints || previous.giftPoints !== this.settings.giftPoints) {
      for (const score of this.scores.values()) score.score = score.comments * this.settings.commentPoints + score.diamonds * this.settings.giftPoints;
    }
    this.changed();
    return this.settings;
  }

  setConnection(status, message) {
    this.connection = { status, message: boundedText(message, 250) };
    this.changed();
  }

  blessing() {
    const list = this.settings.blessings;
    if (!list.length) return '';
    let index = this.settings.blessingMode === 'ordered' ? (this.lastBlessing + 1) % list.length : Math.floor(this.random() * list.length);
    if (list.length > 1 && index === this.lastBlessing) index = (index + 1) % list.length;
    this.lastBlessing = index; return list[index];
  }

  line(template, user = {}, values = {}) {
    return renderTemplate(this.settings[template], {kenh:this.settings.channelName,ten:user.nickname || '',qua:'',soluong:'',binhluan:'',loichuc:'',...values});
  }

  event(input) {
    const event = { id: randomUUID(), at: this.now(), ...input };
    this.events.unshift(event);
    this.events = this.events.slice(0, 100);
    this.emit('event', event);
    return event;
  }

  ensureViewer(input, announce = false) {
    const user = sanitizeUser(input);
    const exists = this.viewers.has(user.id);
    const previous = this.viewers.get(user.id);
    this.viewers.set(user.id, { ...previous, ...user, joinedAt: previous?.joinedAt ?? this.now(), seat: previous?.seat ?? this.viewers.size });
    if (!this.scores.has(user.id)) this.scores.set(user.id, { ...user, score: 0, comments: 0, diamonds: 0, gifts: 0 });
    else this.scores.set(user.id, { ...this.scores.get(user.id), ...user });
    this.stats.viewers = this.remoteViewerCount ?? this.viewers.size;
    if (!exists && announce) this.event({ type: 'join', user, text: `${user.nickname} vừa ghé thăm`, speech: this.settings.greetViewers ? this.line('joinTemplate',user) : undefined, priority: 3 });
    return user;
  }

  queueRitual(user, source, extra = {}) {
    const ritual = { id: randomUUID(), user, source, at: this.now(), config: ritualSnapshot(this.settings), ...extra };
    this.ritualQueue.push(ritual);
    return ritual;
  }

  completeRitual(id) {
    const index = this.ritualQueue.findIndex(item => item.id === id);
    if (index !== 0) return false;
    this.ritualQueue.splice(index, 1);
    this.stats.rituals += 1;
    this.changed();
    return true;
  }

  setViewerCount(count) {
    if (!Number.isFinite(count)) return;
    this.remoteViewerCount = Math.max(0, Math.floor(count));
    this.stats.viewers = this.remoteViewerCount;
    this.changed();
  }

  handle(input) {
    const type = input.type;
    if (!['join', 'comment', 'gift', 'like'].includes(type)) throw new Error('Loại sự kiện không hợp lệ.');
    this.lastActivity = this.now();
    const user = this.ensureViewer(input.user || DEMO_USERS[Math.floor(this.random() * DEMO_USERS.length)], type !== 'join');
    const score = this.scores.get(user.id);
    let result;
    if (type === 'join') {
      result = this.event({ type, user, text: `${user.nickname} vừa ghé thăm`, speech: this.settings.greetViewers ? this.line('joinTemplate',user) : undefined, priority: 3 });
    }
    if (type === 'comment') {
      const text = boundedText(input.text, 500);
      if (!text) throw new Error('Bình luận không được để trống.');
      score.comments += 1;
      score.score += this.settings.commentPoints;
      const prayer = commentBlessing(text, this.settings);
      const incense = isIncenseComment(text, this.settings.incenseKeywords);
      const ritual = incense && this.settings.ritualEnabled && this.settings.incenseOnComment ? this.queueRitual(user, 'comment') : null;
      const speech = this.settings.readComments
        ? incense ? this.line('incenseTemplate',user)
          : prayer ? this.line('commentTemplate',user,{loichuc:prayer})
            : this.line('genericCommentTemplate',user,{binhluan:boundedText(text,180),loichuc:this.blessing()})
        : undefined;
      result = this.event({ type, user, text, speech, priority: 2, ritualId: ritual?.id });
    }
    if (type === 'gift') {
      const count = Math.max(1, Math.min(100000, Math.floor(Number(input.count) || 1)));
      const diamonds = Math.max(0, Math.min(1000000, Math.floor(Number(input.diamonds) || 1)));
      const giftName = boundedText(input.giftName || 'Hoa sen', 80);
      this.stats.gifts += count;
      this.stats.diamonds += diamonds * count;
      score.diamonds += diamonds * count;
      score.gifts += count;
      score.score += diamonds * count * this.settings.giftPoints;
      const ritual = this.settings.ritualEnabled && this.settings.incenseOnGift ? this.queueRitual(user, 'gift', { giftName, count, diamonds }) : null;
      result = this.event({ type, user, giftName, count, diamonds, ritualId: ritual?.id, text: `${user.nickname} dâng ${giftName}${count > 1 ? ` × ${count}` : ''}`, speech: this.line('giftTemplate',user,{qua:giftName,soluong:count,loichuc:this.blessing()}), priority: 0 });
    }
    if (type === 'like') {
      const count = Math.max(1, Math.min(1000000, Math.floor(Number(input.count) || 1)));
      const before = Math.floor(this.stats.likes / this.settings.heartThreshold);
      this.stats.likes += count;
      result = this.event({ type, user, count, text: `${user.nickname} thả ${count} tim` });
      if (Math.floor(this.stats.likes / this.settings.heartThreshold) > before) {
        this.lotusUntil = this.now() + this.settings.lotusRainSeconds * 1000;
        this.event({ type: 'lotus', user, text: `${this.settings.heartThreshold} trái tim · Mưa hoa sen ${this.settings.lotusRainSeconds} giây`, speech: this.line('lotusTemplate'), priority: 2 });
      }
    }
    this.changed();
    return result;
  }

  handleTikTokGift(input) {
    const user = sanitizeUser(input);
    const details = input.giftDetails || input.extendedGiftInfo || input;
    const giftId = boundedText(input.giftId || input.giftName || 'gift', 80);
    const count = Math.max(1, Math.floor(Number(input.repeatCount) || 1));
    const streak = Number(details.giftType ?? input.giftType) === 1;
    const key = `${user.id}:${giftId}`;
    if (streak && !input.repeatEnd) {
      this.giftStreaks.set(key, { ...input, count });
      return null;
    }
    const messageId = input.msgId || input.common?.msgId || input.logId;
    const dedupeKey = messageId ? `${messageId}:${streak ? 'end' : 'single'}` : null;
    if (dedupeKey && this.seenGifts.has(dedupeKey)) return null;
    if (dedupeKey) {
      this.seenGifts.add(dedupeKey);
      if (this.seenGifts.size > 5000) this.seenGifts.delete(this.seenGifts.values().next().value);
    }
    this.giftStreaks.delete(key);
    return this.handle({ type: 'gift', user, count, diamonds: details.diamondCount ?? input.diamondCount, giftName: details.giftName || details.name || input.giftName });
  }

  speak(text, { idle = false } = {}) {
    const value = boundedText(text, 500);
    if (!value) throw new Error('Vui lòng nhập nội dung cần đọc.');
    const event = this.event({ type: 'speak', text: value, speech: value, priority: idle ? 4 : 1, manual: !idle });
    this.changed();
    return event;
  }

  idleTick() {
    const now = this.now();
    if (!this.settings.idleBlessings || now - this.lastActivity < this.settings.idleSeconds * 1000 || now - this.lastIdle < this.settings.idleSeconds * 1000) return null;
    this.lastIdle = now;
    return this.speak(this.line('idleTemplate',{}, {loichuc:this.blessing()}), { idle: true });
  }

  chant() {
    if (!this.settings.chantTexts.length) return null;
    const text = this.settings.chantTexts[this.chantIndex++ % this.settings.chantTexts.length];
    const event = this.event({ type: 'chant', text, speech: text, priority: 4 });
    this.nextChant = this.now() + this.settings.chantEverySec * 1000;
    this.changed();
    return event;
  }

  chantTick() {
    if (!this.settings.autoChant || !this.settings.voiceEnabled || this.now() < this.nextChant) return null;
    return this.chant();
  }

  audioEffect(effect) {
    if (!['bell', 'wood', 'next-music'].includes(effect)) throw new Error('Hiệu ứng âm thanh không hợp lệ.');
    return this.event({ type: 'audio-effect', effect });
  }

  reset() {
    this.viewers.clear(); this.scores.clear(); this.events = []; this.ritualQueue = [];
    this.stats = { viewers: 0, gifts: 0, diamonds: 0, likes: 0, rituals: 0 };
    this.remoteViewerCount = null;
    this.lotusUntil = 0; this.lastActivity = this.now(); this.lastIdle = this.now();
    this.chantIndex = 0; this.nextChant = this.now() + 4000;
    this.giftStreaks.clear(); this.seenGifts.clear();
    if (this.settings.demoMode) this.seedDemo();
    this.changed();
  }
}
