import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';

export const DEFAULT_SETTINGS = Object.freeze({
  channelName: 'Tâm An Lành', tiktokUsername: 'yahyah_155', voiceEnabled: true,
  readComments: true, greetViewers: true, idleBlessings: true,
  volume: 0.85, rate: 0.95, demoMode: true,
});

export const BLESSINGS = [
  'Chúc bạn và gia đình luôn bình an, thân tâm an lạc, mọi việc thuận duyên.',
  'Nguyện những điều tốt lành đến với bạn, sức khỏe dồi dào, nụ cười luôn ở lại.',
  'Chúc bạn một đời an nhiên, đi qua khó khăn bằng trái tim vững vàng.',
  'Nguyện gia đình bạn hòa thuận, yêu thương và hạnh phúc mỗi ngày.',
  'Chúc bạn công việc hanh thông, gặp người tử tế và có nhiều duyên lành.',
  'Nguyện cho tâm bạn nhẹ nhàng, buông xuống muộn phiền và đón nhận bình yên.',
  'Chúc những mong ước thiện lành của bạn sớm thành hiện thực.',
  'Nguyện bạn luôn đủ sức khỏe, đủ niềm tin và đủ yêu thương trên mọi chặng đường.',
  'Chúc bạn hôm nay an vui, ngày mai tươi sáng và mỗi ngày đều có điều đáng biết ơn.',
  'Nguyện phúc lành đến với bạn, nhà nhà ấm áp, người người bình an.',
  'Chúc bạn tìm thấy niềm vui trong những điều giản dị và sự an lạc trong chính mình.',
  'Nguyện mọi nỗ lực chân thành của bạn đều nở hoa, mọi bước chân đều gặp thuận duyên.',
];

const COMMENT_WISHES = [
  { words: ['thi cu', 'thi tot', 'thi dau', 'thi do', 'diem cao', 'hoc tap', 'dai hoc', 'tot nghiep', 'hoc sinh', 'bai thi'], text: 'Chúc bạn học tập vững vàng, giữ tâm bình tĩnh, tự tin làm bài và đạt kết quả xứng đáng với công sức của mình.' },
  { words: ['suc khoe', 'benh', 'khoi', 'phau thuat', 'dieu tri', 'ung thu', 'benh vien'], text: 'Chúc bạn và người thân sức khỏe dồi dào, tinh thần vững vàng, sớm vượt qua những ngày khó khăn và luôn được chăm sóc chu đáo.' },
  { words: ['tinh duyen', 'tinh yeu', 'nguoi yeu', 'ket hon', 'vo chong', 'hon nhan', 'chia tay'], text: 'Chúc đường tình duyên của bạn gặp nhiều duyên lành, được yêu thương chân thành, biết lắng nghe và cùng nhau vun đắp hạnh phúc.' },
  { words: ['gia dinh', 'cha me', 'ba me', 'bo me', 'ong ba', 'con cai', 'con chau', 'gia dao'], text: 'Chúc gia đình bạn luôn khỏe mạnh, hòa thuận, biết yêu thương và gìn giữ những phút giây sum vầy.' },
  { words: ['cong viec', 'viec lam', 'kinh doanh', 'buon ban', 'lam an', 'tai loc', 'su nghiep', 'phong van'], text: 'Chúc công việc của bạn thuận lợi, kinh doanh chân chính, gặp người đồng hành tốt và gặt hái thành quả từ sự nỗ lực.' },
  { words: ['binh an', 'an lanh', 'an lac', 'hanh phuc', 'muon phien', 'buon', 'lo lang'], text: 'Chúc bạn tâm an, lòng nhẹ, vững vàng trước những điều chưa như ý và tìm thấy niềm vui trong từng ngày.' },
];

export function normalizeText(value) {
  return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().replace(/\s+/g, ' ').trim();
}

function boundedText(value, max = 300) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

export function safeAvatar(value) {
  if (typeof value !== 'string' || value.length > 2048) return '';
  if (/^\/api\/avatar\/[a-z0-9_-]+(?:\?[^\s]*)?$/i.test(value)) return value;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
  } catch { return ''; }
}

export function sanitizeUser(input = {}) {
  input = input.user || input;
  const id = boundedText(input.id || input.uniqueId || input.userId || input.nickname || 'khach', 100);
  const nickname = boundedText(input.nickname || input.uniqueId || 'Bạn hữu duyên', 60);
  const rawAvatar = input.avatar || input.profilePictureUrl || input.profilePicture?.url?.[0] || '';
  return { id, nickname, avatar: safeAvatar(rawAvatar) };
}

export function commentBlessing(text) {
  const normalized = normalizeText(text);
  return COMMENT_WISHES.find(({ words }) => words.some(word => normalized.includes(word)))?.text ?? null;
}

export function isIncenseComment(text) {
  const compact = normalizeText(text).replace(/[^a-z0-9]/g, '');
  return compact.includes('adidaphat') || compact.includes('namoadidaphat');
}

export function sanitizeSettings(input = {}, existing = DEFAULT_SETTINGS) {
  const next = { ...existing };
  if (typeof input.channelName === 'string') next.channelName = boundedText(input.channelName, 60) || DEFAULT_SETTINGS.channelName;
  if (typeof input.tiktokUsername === 'string') next.tiktokUsername = input.tiktokUsername.replace(/^@/, '').replace(/[^a-zA-Z0-9_.]/g, '').slice(0, 64);
  for (const name of ['voiceEnabled', 'readComments', 'greetViewers', 'idleBlessings', 'demoMode']) {
    if (typeof input[name] === 'boolean') next[name] = input[name];
  }
  if (Number.isFinite(Number(input.volume))) next.volume = Math.max(0, Math.min(1, Number(input.volume)));
  if (Number.isFinite(Number(input.rate))) next.rate = Math.max(0.6, Math.min(1.5, Number(input.rate)));
  return next;
}

export const DEMO_USERS = [
  { id: 'minhan', nickname: 'Minh An', avatar: '/api/avatar/minhan?name=Minh%20An' },
  { id: 'thanhha', nickname: 'Thanh Hà', avatar: '/api/avatar/thanhha?name=Thanh%20H%C3%A0' },
  { id: 'ngoclinh', nickname: 'Ngọc Linh', avatar: '/api/avatar/ngoclinh?name=Ng%E1%BB%8Dc%20Linh' },
  { id: 'hoangnam', nickname: 'Hoàng Nam', avatar: '/api/avatar/hoangnam?name=Ho%C3%A0ng%20Nam' },
  { id: 'anhnhi', nickname: 'Anh Nhi', avatar: '/api/avatar/anhnhi?name=Anh%20Nhi' },
  { id: 'phucloc', nickname: 'Phúc Lộc', avatar: '/api/avatar/phucloc?name=Ph%C3%BAc%20L%E1%BB%99c' },
  { id: 'nhuy', nickname: 'Như Ý', avatar: '/api/avatar/nhuy?name=Nh%C6%B0%20%C3%9D' },
  { id: 'giabao', nickname: 'Gia Bảo', avatar: '/api/avatar/giabao?name=Gia%20B%E1%BA%A3o' },
];

export class LiveEngine extends EventEmitter {
  constructor(settings = {}, { now = Date.now, random = Math.random, seed = true } = {}) {
    super();
    this.now = now;
    this.random = random;
    this.settings = sanitizeSettings(settings);
    this.connection = { status: this.settings.demoMode ? 'demo' : 'disconnected', message: this.settings.demoMode ? 'Đang chạy chế độ trải nghiệm' : 'Chưa kết nối TikTok LIVE' };
    this.viewers = new Map();
    this.scores = new Map();
    this.events = [];
    this.ritualQueue = [];
    this.stats = { viewers: 0, gifts: 0, diamonds: 0, likes: 0, rituals: 0 };
    this.remoteViewerCount = null;
    this.lotusUntil = 0;
    this.lastActivity = this.now();
    this.lastIdle = this.now();
    this.lastBlessing = -1;
    this.giftStreaks = new Map();
    this.seenGifts = new Set();
    if (seed && this.settings.demoMode) this.seedDemo();
  }

  seedDemo() {
    DEMO_USERS.forEach((user, index) => {
      this.viewers.set(user.id, { ...user, joinedAt: this.now(), seat: index });
      this.scores.set(user.id, { ...user, score: [328, 256, 186, 128, 98, 72, 56, 32][index], comments: [18, 16, 16, 18, 18, 12, 6, 2][index], diamonds: [31, 24, 17, 11, 8, 6, 5, 3][index], gifts: [12, 9, 8, 5, 4, 3, 2, 1][index] });
    });
    this.stats.viewers = this.remoteViewerCount ?? this.viewers.size;
    this.stats.likes = 328;
  }

  getState() {
    return {
      settings: { ...this.settings }, connection: { ...this.connection },
      viewers: [...this.viewers.values()],
      leaderboard: [...this.scores.values()].sort((a, b) => b.score - a.score).slice(0, 30),
      stats: { ...this.stats }, events: [...this.events], ritualQueue: [...this.ritualQueue], lotusUntil: this.lotusUntil,
    };
  }

  changed() { this.emit('state', this.getState()); }

  setSettings(input) {
    this.settings = sanitizeSettings(input, this.settings);
    if (this.settings.demoMode && ['disconnected', 'error', 'demo'].includes(this.connection.status)) {
      this.connection = { status: 'demo', message: 'Đang chạy chế độ trải nghiệm' };
    } else if (!this.settings.demoMode && this.connection.status === 'demo') {
      this.connection = { status: 'disconnected', message: 'Chưa kết nối TikTok LIVE' };
    }
    this.changed();
    return this.settings;
  }

  setConnection(status, message) {
    this.connection = { status, message: boundedText(message, 250) };
    this.changed();
  }

  blessing() {
    let index = Math.floor(this.random() * BLESSINGS.length);
    if (index === this.lastBlessing) index = (index + 1) % BLESSINGS.length;
    this.lastBlessing = index;
    return BLESSINGS[index];
  }

  event(input) {
    const event = { id: randomUUID(), at: this.now(), ...input };
    this.events.unshift(event);
    this.events = this.events.slice(0, 100);
    this.emit('event', event);
    return event;
  }

  ensureViewer(input, announce = false) {
    const user = sanitizeUser(input);
    const exists = this.viewers.has(user.id);
    const previous = this.viewers.get(user.id);
    this.viewers.set(user.id, { ...previous, ...user, joinedAt: previous?.joinedAt ?? this.now(), seat: previous?.seat ?? this.viewers.size });
    if (!this.scores.has(user.id)) this.scores.set(user.id, { ...user, score: 0, comments: 0, diamonds: 0, gifts: 0 });
    else this.scores.set(user.id, { ...this.scores.get(user.id), ...user });
    this.stats.viewers = this.remoteViewerCount ?? this.viewers.size;
    if (!exists && announce) this.event({ type: 'join', user, text: `${user.nickname} vừa ghé thăm`, speech: this.settings.greetViewers ? `${this.settings.channelName} chào ${user.nickname}. Chúc bạn một buổi an lành, mời bạn an tọa và cùng gửi những nguyện lành.` : undefined, priority: 3 });
    return user;
  }

  queueRitual(user, source, extra = {}) {
    const ritual = { id: randomUUID(), user, source, at: this.now(), ...extra };
    this.ritualQueue.push(ritual);
    return ritual;
  }

  completeRitual(id) {
    const index = this.ritualQueue.findIndex(item => item.id === id);
    if (index < 0) return false;
    this.ritualQueue.splice(index, 1);
    this.stats.rituals += 1;
    this.changed();
    return true;
  }

  setViewerCount(count) {
    if (!Number.isFinite(count)) return;
    this.remoteViewerCount = Math.max(0, Math.floor(count));
    this.stats.viewers = this.remoteViewerCount;
    this.changed();
  }

  handle(input) {
    const type = input.type;
    if (!['join', 'comment', 'gift', 'like'].includes(type)) throw new Error('Loại sự kiện không hợp lệ.');
    this.lastActivity = this.now();
    const user = this.ensureViewer(input.user || DEMO_USERS[Math.floor(this.random() * DEMO_USERS.length)], type !== 'join');
    const score = this.scores.get(user.id);
    let result;
    if (type === 'join') {
      result = this.event({ type, user, text: `${user.nickname} vừa ghé thăm`, speech: this.settings.greetViewers ? `${this.settings.channelName} chào ${user.nickname}. Chúc bạn tâm an, mọi điều thuận duyên. Mời bạn an tọa.` : undefined, priority: 3 });
    }
    if (type === 'comment') {
      const text = boundedText(input.text, 500);
      if (!text) throw new Error('Bình luận không được để trống.');
      score.comments += 1;
      score.score += 1;
      const prayer = commentBlessing(text);
      const incense = isIncenseComment(text);
      const ritual = incense ? this.queueRitual(user, 'comment') : null;
      const speech = this.settings.readComments
        ? incense ? `${this.settings.channelName} kính chúc ${user.nickname} thân tâm an lạc, gia đạo bình an. A Di Đà Phật.`
          : prayer ? `${this.settings.channelName} gửi lời chúc đến ${user.nickname}. ${prayer}`
            : `${this.settings.channelName} nhận được lời nhắn của ${user.nickname}: ${boundedText(text, 180)}. ${this.blessing()}`
        : undefined;
      result = this.event({ type, user, text, speech, priority: 2, ritualId: ritual?.id });
    }
    if (type === 'gift') {
      const count = Math.max(1, Math.min(100000, Math.floor(Number(input.count) || 1)));
      const diamonds = Math.max(0, Math.min(1000000, Math.floor(Number(input.diamonds) || 1)));
      const giftName = boundedText(input.giftName || 'Hoa sen', 80);
      this.stats.gifts += count;
      this.stats.diamonds += diamonds * count;
      score.diamonds += diamonds * count;
      score.gifts += count;
      score.score += diamonds * count * 10;
      const ritual = this.queueRitual(user, 'gift', { giftName, count, diamonds });
      result = this.event({ type, user, giftName, count, diamonds, ritualId: ritual.id, text: `${user.nickname} dâng ${giftName}${count > 1 ? ` × ${count}` : ''}`, speech: `${this.settings.channelName} xin cảm ơn ${user.nickname} đã gửi ${count > 1 ? count + ' ' : ''}${giftName}. ${this.blessing()}`, priority: 0 });
    }
    if (type === 'like') {
      const count = Math.max(1, Math.min(1000000, Math.floor(Number(input.count) || 1)));
      const before = Math.floor(this.stats.likes / 666);
      this.stats.likes += count;
      result = this.event({ type, user, count, text: `${user.nickname} thả ${count} tim` });
      if (Math.floor(this.stats.likes / 666) > before) {
        this.lotusUntil = this.now() + 60000;
        this.event({ type: 'lotus', user, text: '666 trái tim · Mưa hoa sen 60 giây', speech: `${this.settings.channelName} cảm ơn những trái tim yêu thương. Xin gửi một cơn mưa hoa sen và lời chúc an lành đến tất cả mọi người.`, priority: 2 });
      }
    }
    this.changed();
    return result;
  }

  handleTikTokGift(input) {
    const user = sanitizeUser(input);
    const details = input.giftDetails || input.extendedGiftInfo || input;
    const giftId = boundedText(input.giftId || input.giftName || 'gift', 80);
    const count = Math.max(1, Math.floor(Number(input.repeatCount) || 1));
    const streak = Number(details.giftType ?? input.giftType) === 1;
    const key = `${user.id}:${giftId}`;
    if (streak && !input.repeatEnd) {
      this.giftStreaks.set(key, { ...input, count });
      return null;
    }
    const messageId = input.msgId || input.common?.msgId || input.logId;
    const dedupeKey = messageId ? `${messageId}:${streak ? 'end' : 'single'}` : null;
    if (dedupeKey && this.seenGifts.has(dedupeKey)) return null;
    if (dedupeKey) {
      this.seenGifts.add(dedupeKey);
      if (this.seenGifts.size > 5000) this.seenGifts.delete(this.seenGifts.values().next().value);
    }
    this.giftStreaks.delete(key);
    return this.handle({ type: 'gift', user, count, diamonds: details.diamondCount ?? input.diamondCount, giftName: details.giftName || details.name || input.giftName });
  }

  speak(text, { idle = false } = {}) {
    const value = boundedText(text, 500);
    if (!value) throw new Error('Vui lòng nhập nội dung cần đọc.');
    const event = this.event({ type: 'speak', text: value, speech: value, priority: idle ? 4 : 1, manual: !idle });
    this.changed();
    return event;
  }

  idleTick() {
    const now = this.now();
    if (!this.settings.idleBlessings || now - this.lastActivity < 90000 || now - this.lastIdle < 90000) return null;
    this.lastIdle = now;
    return this.speak(`${this.settings.channelName} gửi lời chúc an lành đến tất cả mọi người. ${this.blessing()} Nếu thấy lòng mình nhẹ hơn, mời bạn chia sẻ buổi live để cùng lan tỏa những điều tốt đẹp.`, { idle: true });
  }

  reset() {
    this.viewers.clear(); this.scores.clear(); this.events = []; this.ritualQueue = [];
    this.stats = { viewers: 0, gifts: 0, diamonds: 0, likes: 0, rituals: 0 };
    this.remoteViewerCount = null;
    this.lotusUntil = 0; this.lastActivity = this.now(); this.lastIdle = this.now();
    this.giftStreaks.clear(); this.seenGifts.clear();
    if (this.settings.demoMode) this.seedDemo();
    this.changed();
  }
}
