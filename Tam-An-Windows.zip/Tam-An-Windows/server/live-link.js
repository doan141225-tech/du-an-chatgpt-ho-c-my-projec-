import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CLOUDFLARED, downloadVerified } from './cloudflared.js';
import { createWidgetRelay } from './widget-relay.js';

export function quickTunnelOrigin(text){return String(text).match(/https:\/\/[a-z0-9]+(?:-[a-z0-9]+)*\.trycloudflare\.com(?![a-z0-9.-])/i)?.[0]?.toLowerCase()||'';}
export class LiveLink {
  constructor({engine,distDir,dataDir,avatarHandler,platform=process.platform,arch=process.arch,download=downloadVerified,launch=spawn,relayFactory=createWidgetRelay,startTimeout=90000}){
    Object.assign(this,{engine,distDir,dataDir,avatarHandler,platform,arch,download,launch,relayFactory,startTimeout});
    this.current={state:'idle',message:'Chưa tạo link HTTPS.',progress:0,url:''};this.generation=0;
  }
  status(){return {...this.current,supported:this.platform==='win32'&&this.arch==='x64'};}
  start(){
    if(!this.status().supported){this.current={state:'error',message:'Chức năng tạo link chạy trên bộ Windows64-bit của bạn.',progress:0,url:''};return this.status();}
    if(['downloading','starting','ready','stopping'].includes(this.current.state))return this.status();
    const generation=++this.generation;this.abort=new AbortController();
    this.current={state:'downloading',message:'Đang kiểm tra bộ tạo HTTPS…',progress:0,url:''};
    this.job=this.prepare(generation).catch(async()=>{
      if(this.generation!==generation)return;
      await this.clean();
      this.current={state:'error',message:'Chưa tạo được link HTTPS. Kiểm tra Internet/tường lửa rồi bấm thử lại. Trang điều khiển vẫn hoạt động trên máy bạn.',progress:0,url:''};
    });
    return this.status();
  }
  async prepare(generation){
    const active=()=>this.generation===generation&&!this.abort.signal.aborted;
    const signal=AbortSignal.any([this.abort.signal,AbortSignal.timeout(300000)]);
    const binary=await this.download({file:path.resolve(this.dataDir,'..','runtime','cloudflared-'+CLOUDFLARED.version+'.exe'),url:CLOUDFLARED.url,sha256:CLOUDFLARED.sha256,signal,onProgress:progress=>{if(active())this.current.progress=progress;}});
    if(!active())return;
    this.current={state:'starting',message:'Đang kết nối để tạo link HTTPS…',progress:100,url:''};
    const relay=await this.relayFactory({engine:this.engine,distDir:this.distDir,avatarHandler:this.avatarHandler});
    if(!active()){await relay.close();return;}this.relay=relay;
    const config=path.join(this.dataDir,'tunnel','quick.yml');await mkdir(path.dirname(config),{recursive:true});await writeFile(config,'{}\n',{mode:0o600});
    if(!active())return;
    const child=this.launch(binary,['tunnel','--config',config,'--url',`http://127.0.0.1:${relay.port}`,'--protocol','http2','--edge-ip-version','4','--no-autoupdate'],{cwd:this.dataDir,env:process.env,windowsHide:true,stdio:['ignore','pipe','pipe']});
    this.child=child;
    let origin='',connected=false,tail='';
    const ready=()=>{
      if(!active()||!origin||!connected)return;
      clearTimeout(this.deadline);relay.setPublicOrigin(origin);
      // The capability path is shown only in the local, admin-authorized UI.
      this.current={state:'ready',message:'Link HTTPS đã sẵn sàng. Sao chép để dán vào LIVE Studio.',progress:100,url:origin+relay.prefix+'/overlay?audio=1'};
    };
    const output=chunk=>{
      if(!active())return;tail=(tail+chunk.toString()).slice(-16000);
      origin=quickTunnelOrigin(tail)||origin;
      if(/Registered tunnel connection/i.test(tail))connected=true;
      ready();
    };
    child.stdout?.on('data',output);child.stderr?.on('data',output);
    child.once('error',()=>void this.failed(generation));
    child.once('exit',()=>void this.failed(generation));
    this.deadline=setTimeout(()=>{if(active()&&this.current.state!=='ready')void this.failed(generation);},this.startTimeout);
  }
  async failed(generation){
    if(this.generation!==generation)return;
    this.generation++;this.abort?.abort();await this.clean();
    this.current={state:'error',message:'Kết nối tạo link đã dừng. Kiểm tra Internet rồi bấm Tạo link HTTPS để thử lại.',progress:0,url:''};
  }
  async clean(){
    clearTimeout(this.deadline);this.deadline=null;
    const child=this.child;this.child=null;
    if(child){child.removeAllListeners('error');child.removeAllListeners('exit');child.on('error',()=>{});if(child.exitCode===null)child.kill();}
    const relay=this.relay;this.relay=null;if(relay)await relay.close();
  }
  async stop(){
    this.generation++;this.abort?.abort();this.current={state:'stopping',message:'Đang dừng link HTTPS…',progress:0,url:''};
    await this.clean();this.current={state:'idle',message:'Link HTTPS đã dừng.',progress:0,url:''};return this.status();
  }
}
