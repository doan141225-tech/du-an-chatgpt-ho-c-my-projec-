import { createHash } from 'node:crypto';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';
import { HttpsProxyAgent } from 'hpagent';
import { EDGE_VOICES } from './audio-config.js';

export function edgeOptions(input = {}) {
  const clamp = (v, low, high, fallback) => Number.isFinite(Number(v)) ? Math.max(low, Math.min(high, Number(v))) : fallback;
  return {
    voice: EDGE_VOICES.includes(input.voice) ? input.voice : EDGE_VOICES[0],
    pitch: Math.round(clamp(input.pitch, -50, 50, -18)),
    rate: clamp(input.rate, 0.5, 1.5, 0.8),
  };
}
export const escapeSpeech = text => String(text).replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));
export const voiceCacheKey = (text, options) => createHash('sha256').update(JSON.stringify([text, edgeOptions(options)])).digest('hex');

export function collectEdgeAudio(stream) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0, ended = false;
    stream.on('data', chunk => {
      size += chunk.length;
      if (size > 8 * 1024 * 1024) stream.destroy(new Error('Speech audio too large'));
      else chunks.push(chunk);
    });
    stream.once('error', reject);
    stream.once('end', () => { ended = true; size >= 500 ? resolve(Buffer.concat(chunks)) : reject(new Error('Empty speech audio')); });
    stream.once('close', () => { if (!ended) reject(new Error('Speech audio ended before completion')); });
  });
}

const cache = new Map();
const pending = new Map();
let lastSuccessAt = null, lastError = null;
export function edgeStatus() { return { configured: true, verified: !!lastSuccessAt, lastSuccessAt, lastError }; }

export async function synthesizeEdge(text, input = {}) {
  if (typeof text !== 'string' || !text.trim() || text.length > 500) throw new Error('Nội dung cần đọc phải có từ 1 đến 500 ký tự.');
  const options = edgeOptions(input), key = voiceCacheKey(text, options);
  const cached = cache.get(key);
  if (cached && cached.until > Date.now()) return cached.audio;
  if (pending.has(key)) return pending.get(key);
  const job = (async () => {
    const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
    const client = new MsEdgeTTS({ connectionTimeoutMs: 8000, synthesisTimeoutMs: 15000,
      ...(proxy ? { agent: new HttpsProxyAgent({ proxy }) } : {}),
    });
    let timer;
    try {
      const work = (async () => {
        await client.setMetadata(options.voice, OUTPUT_FORMAT.AUDIO_24KHZ_96KBITRATE_MONO_MP3);
        const rate = Math.round((options.rate - 1) * 100);
        const { audioStream } = client.toStream(escapeSpeech(text), {
          pitch: `${options.pitch >= 0 ? '+' : ''}${options.pitch}Hz`,
          rate: `${rate >= 0 ? '+' : ''}${rate}%`,
        });
        return collectEdgeAudio(audioStream);
      })();
      const audio = await Promise.race([work, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Edge speech timeout')), 20000); })]);
      lastSuccessAt = Date.now(); lastError = null;
      cache.set(key, { audio, until: Date.now() + 600000 });
      while (cache.size > 32) cache.delete(cache.keys().next().value);
      return audio;
    } catch {
      lastError = 'Không kết nối được giọng Microsoft Edge. Kiểm tra Internet hoặc đổi bộ đọc.';
      throw new Error(lastError);
    } finally { clearTimeout(timer); client.close(); }
  })();
  pending.set(key, job);
  try { return await job; } finally { pending.delete(key); }
}
