import { Router } from 'express';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const localRoot = path.join(repositoryRoot, '.local', 'tts', 'usr');
const localBinary = path.join(localRoot, 'bin', 'espeak-ng');
const localLibrary = path.join(localRoot, 'lib', 'x86_64-linux-gnu');

export function speechEngineConfig(platform = process.platform) {
  if (platform === 'win32') {
    const candidates = [
      path.join(repositoryRoot, '.local', 'tts-windows', 'espeak-ng.exe'),
      process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'eSpeak NG', 'espeak-ng.exe'),
      process.env['ProgramFiles(x86)'] && path.join(process.env['ProgramFiles(x86)'], 'eSpeak NG', 'espeak-ng.exe'),
    ].filter(Boolean);
    const binary = candidates.find(candidate => existsSync(candidate));
    return {
      command: binary || 'espeak-ng.exe',
      // eSpeak expects the parent of espeak-ng-data, not the data directory itself.
      args: binary ? [`--path=${path.dirname(binary)}`] : [],
      env: process.env,
    };
  }
  const local = existsSync(localBinary);
  return {
    command: local ? localBinary : 'espeak-ng',
    args: local ? [`--path=${localLibrary}`] : [],
    env: local ? {
      ...process.env,
      LD_LIBRARY_PATH: [localLibrary, process.env.LD_LIBRARY_PATH].filter(Boolean).join(path.delimiter),
    } : process.env,
  };
}

function runEngine(args, text = '') {
  return new Promise((resolve, reject) => {
    const config = speechEngineConfig();
    const child = spawn(config.command, [...config.args, ...args], {
      env: config.env,
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    const chunks = [];
    let length = 0;
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      error ? reject(error) : resolve(value);
    };
    const timeout = setTimeout(() => {
      child.kill('SIGKILL');
      finish(new Error('Vietnamese speech generation timed out'));
    }, 12_000);
    timeout.unref();
    child.on('error', () => finish(new Error('Vietnamese speech engine is unavailable')));
    child.stdout.on('data', (chunk) => {
      length += chunk.length;
      if (length > 8 * 1024 * 1024) {
        child.kill('SIGKILL');
        finish(new Error('Speech audio exceeds the size limit'));
      } else {
        chunks.push(chunk);
      }
    });
    // Engine errors may contain machine paths; return an explanatory public error instead.
    child.stderr.on('data', () => {});
    child.stdin.on('error', () => {});
    child.on('close', (code) => code === 0
      ? finish(null, Buffer.concat(chunks))
      : finish(new Error('Vietnamese speech generation failed')));
    child.stdin.end(text);
  });
}

export async function synthesizeVietnamese(text, rate = 1) {
  const normalized = String(text ?? '').normalize('NFC').trim();
  if (!normalized || normalized.length > 500) throw new Error('Text must contain 1–500 characters');
  const speed = Math.round(155 * Math.min(1.4, Math.max(0.6, Number(rate) || 1)));
  const audio = await runEngine(['--stdout', '-v', 'vi', '-b', '1', '-s', String(speed), '--stdin'], normalized);
  if (audio.length < 44 || audio.toString('ascii', 0, 4) !== 'RIFF' || audio.toString('ascii', 8, 12) !== 'WAVE') {
    throw new Error('Speech engine returned invalid audio');
  }
  // espeak's stdout is a stream and carries an unknown data length. Repair its
  // RIFF header now that the full buffer exists, so browsers know its duration.
  audio.writeUInt32LE(audio.length - 8, 4);
  let offset = 12;
  while (offset + 8 <= audio.length) {
    const kind = audio.toString('ascii', offset, offset + 4);
    if (kind === 'data') {
      audio.writeUInt32LE(audio.length - offset - 8, offset + 4);
      break;
    }
    const size = audio.readUInt32LE(offset + 4);
    offset += 8 + size + (size % 2);
  }
  return audio;
}

export function createTtsRouter() {
  const router = Router();
  let active = 0;
  let available;
  const probe = async () => {
    if (available === undefined) {
      available = await runEngine(['--voices=vi']).then((output) => output.toString().includes('Vietnamese')).catch(() => false);
    }
    return available;
  };

  router.get('/status', async (_req, res) => {
    res.json({ available: await probe(), engine: 'espeak-ng', voice: 'vi', offline: true });
  });

  router.get('/', async (req, res) => {
    const text = typeof req.query.text === 'string' ? req.query.text.trim() : '';
    if (!text || text.length > 500) {
      return res.status(400).json({ error: 'Nội dung cần đọc phải có từ 1 đến 500 ký tự.' });
    }
    if (active >= 2) {
      return res.status(429).json({ error: 'Giọng đọc đang bận. Vui lòng thử lại sau giây lát.' });
    }
    if (!await probe()) {
      return res.status(503).json({ error: 'Chưa cài giọng đọc tiếng Việt ngoại tuyến. Hãy dùng trình duyệt có giọng vi-VN hoặc cài espeak-ng.' });
    }
    active += 1;
    try {
      const audio = await synthesizeVietnamese(text, req.query.rate);
      res.set({
        'Content-Type': 'audio/wav',
        'Content-Length': String(audio.length),
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
      });
      res.send(audio);
    } catch {
      if (!res.headersSent) res.status(503).json({ error: 'Không tạo được giọng đọc tiếng Việt. Vui lòng thử lại.' });
    } finally {
      active -= 1;
    }
  });
  return router;
}
