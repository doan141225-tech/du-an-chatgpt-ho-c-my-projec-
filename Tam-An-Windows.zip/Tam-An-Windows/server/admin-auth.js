import { Router } from 'express';
import { randomBytes, scrypt as scryptCallback, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdir, readFile, writeFile, rename, rm } from 'node:fs/promises';
import { dirname } from 'node:path';

const scrypt = promisify(scryptCallback);
export async function hashPin(pin, salt = randomBytes(16).toString('hex')) {
  if (!/^\d{4,12}$/.test(String(pin))) throw new Error('Mã PIN cần từ 4 đến 12 chữ số.');
  return { salt, hash: (await scrypt(String(pin), salt, 64)).toString('hex') };
}
export async function verifyPin(pin, credentials) {
  if (!/^\d{4,12}$/.test(String(pin)) || !credentials) return false;
  const actual = await scrypt(String(pin), credentials.salt, 64);
  const expected = Buffer.from(credentials.hash, 'hex');
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
const digest = value => createHash('sha256').update(value).digest('hex');
const COOKIE = 'tam_an_admin';

export async function createAdminAuth(file) {
  let credentials = null;
  try {
    credentials = JSON.parse(await readFile(file, 'utf8'));
    if (!/^[a-f0-9]{32}$/.test(credentials.salt) || !/^[a-f0-9]{128}$/.test(credentials.hash)) throw new Error('Tệp khóa quản trị không hợp lệ.');
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const sessions = new Map(), attempts = new Map();
  const token = req => req.headers.cookie?.split(';').map(v=>v.trim()).find(v=>v.startsWith(COOKIE+'='))?.slice(COOKIE.length+1) || '';
  const isAdmin = req => !credentials || (sessions.get(digest(token(req))) || 0) > Date.now();
  const requireAdmin = (req,res,next) => isAdmin(req) ? next() : res.status(401).json({ error:'Cần đăng nhập quản trị để thay đổi cài đặt.' });
  const grant = res => {
    const value = randomBytes(32).toString('hex');
    sessions.set(digest(value), Date.now()+8*3600*1000);
    for (const [key,until] of sessions) if (until < Date.now()) sessions.delete(key);
    res.cookie(COOKIE,value,{httpOnly:true,sameSite:'strict',maxAge:8*3600*1000,path:'/'});
  };
  const router = Router();
  router.get('/status',(req,res)=>res.json({pinEnabled:!!credentials,admin:isAdmin(req)}));
  router.post('/login',async(req,res,next)=>{
    try {
      const now=Date.now(), key=req.ip;
      let attempt=attempts.get(key); if(!attempt || attempt.until < now){attempt={count:0,until:now+60000};attempts.set(key,attempt);}
      if(++attempt.count>8) return res.status(429).json({error:'Sai PIN nhiều lần. Vui lòng thử lại sau một phút.'});
      if(credentials && !await verifyPin(req.body?.pin,credentials)) return res.status(401).json({error:'Mã PIN chưa đúng.'});
      attempts.delete(key);grant(res);res.json({ok:true});
    }catch(error){next(error);}
  });
  router.post('/logout',(req,res)=>{sessions.delete(digest(token(req)));res.clearCookie(COOKIE,{path:'/'});res.json({ok:true});});
  router.post('/pin',requireAdmin,async(req,res,next)=>{
    try {
      if(req.body?.pin===''){
        await rm(file,{force:true});credentials=null;sessions.clear();res.clearCookie(COOKIE,{path:'/'});
      }else{
        const nextPin=await hashPin(req.body?.pin);
        await mkdir(dirname(file),{recursive:true});await writeFile(file+'.tmp',JSON.stringify(nextPin),{mode:0o600});await rename(file+'.tmp',file);
        credentials=nextPin;sessions.clear();grant(res);
      }
      res.json({ok:true,pinEnabled:!!credentials});
    }catch(error){next(error);}
  });
  const protect = (req,res,next) => {
    if(req.method==='GET'||req.method==='HEAD'||req.path==='/ritual/complete')return next();
    return requireAdmin(req,res,next);
  };
  return {router,protect,requireAdmin};
}
