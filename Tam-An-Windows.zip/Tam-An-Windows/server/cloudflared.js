import https from 'node:https';
import { createHash, randomBytes } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, rename, rm, chmod } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import path from 'node:path';
import { HttpsProxyAgent } from 'hpagent';

export const CLOUDFLARED = Object.freeze({
  version:'2026.10.7',
  url:'https://github.com/cloudflare/cloudflared/releases/download/2026.10.7/cloudflared-windows-amd64.exe',
  sha256:'2493dbc168923bb3e59e5e7716f71deced92992eea9acd6e9d74f84ac7751343',
});
const HOSTS=new Set(['github.com','release-assets.githubusercontent.com','objects.githubusercontent.com']);
export function openDownload(address,signal,redirects=0){
  return new Promise((resolve,reject)=>{
    const url=new URL(address);
    if(url.protocol!=='https:'||!HOSTS.has(url.hostname)||url.username||url.password||redirects>5)return reject(new Error('Untrusted download destination'));
    const proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY;
    const req=https.get(url,{signal,...(proxy?{agent:new HttpsProxyAgent({proxy})}:{}),headers:{'User-Agent':'Tam-An-Studio/1.3'}},res=>{
      if([301,302,303,307,308].includes(res.statusCode)&&res.headers.location){res.resume();resolve(openDownload(new URL(res.headers.location,url).href,signal,redirects+1));}
      else if(res.statusCode===200)resolve(res);
      else{res.resume();reject(new Error('Download service rejected the request'));}
    });
    req.on('error',reject);
  });
}
export async function fileHash(filename){const hash=createHash('sha256');for await(const chunk of createReadStream(filename))hash.update(chunk);return hash.digest('hex');}
export async function downloadVerified({file,url,sha256,signal,onProgress=()=>{},transport=openDownload}){
  await mkdir(path.dirname(file),{recursive:true});
  try{if(await fileHash(file)===sha256)return file;await rename(file,file+'.invalid-'+Date.now());}catch(error){if(error.code!=='ENOENT')throw error;}
  const temp=file+'.part-'+randomBytes(6).toString('hex');
  try{
    const stream=await transport(url,signal);const total=Number(stream.headers?.['content-length'])||0;
    let size=0;const hash=createHash('sha256');
    const meter=new Transform({transform(chunk,_encoding,callback){size+=chunk.length;if(size>100*1024*1024)return callback(new Error('Download exceeds size limit'));hash.update(chunk);onProgress(total?Math.min(99,Math.round(size/total*100)):0);callback(null,chunk);}});
    await pipeline(stream,meter,createWriteStream(temp,{mode:0o700}),{signal});
    if(hash.digest('hex')!==sha256)throw new Error('Cloudflared checksum mismatch');
    await rename(temp,file);await chmod(file,0o700);onProgress(100);return file;
  }catch(error){await rm(temp,{force:true});throw error;}
}
