import express from 'express';
import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { WebSocketServer, WebSocket } from 'ws';
import { createTtsRouter } from './tts.js';

const OUTPUT_SETTINGS = new Set([
  'channelName','voiceEnabled','volume','rate','commentRate','voiceEngine','voice','pitch','voiceFallback','browserVoice',
  'musicEnabled','musicVolume','musicMode','musicDuck','musicDuckLevel','musicCrossfade','moEnabled','moBpm','sfxVolume','bellEnabled','autoChant',
  'effectsEnabled','giftCameraEnabled','giftCameraZoom','goldenLotusEnabled','giftPetalsEnabled','ambientPetalsEnabled','petalCount','petalFallSpeed','characterScale','maxVisibleViewers','sceneBrightness','giftCardSeconds',
  'showChannelInfo','showLeaderBoard','showOfferingGuide','showPrayerHint','showHeartProgress','showWatermark','showNameplates','showAvatars',
  'stageTitle','stageEyebrow','watermarkText','leaderboardTitle','stageLeaderboardSize','giftCardLabel','giftCardBlessing','heartThreshold','lotusRainSeconds',
  'ritualEnabled','incenseOnComment','incenseKeywords','walkSpeed','returnSpeed','incenseDuration','bowCount','bowDuration','bowAngle',
]);
export function widgetState(state) {
  return {
    settings: Object.fromEntries(Object.entries(state.settings).filter(([key])=>OUTPUT_SETTINGS.has(key))),
    connection: {status:state.connection.status},viewers:state.viewers,leaderboard:state.leaderboard,stats:state.stats,ritualQueue:state.ritualQueue,lotusUntil:state.lotusUntil,events:[],
  };
}
export function rewriteWidgetHtml(html, prefix) {
  return html.replace(/\b(src|href)=(['"])\//g,(_m,attr,quote)=>`${attr}=${quote}${prefix}/`);
}

/** Public server deliberately has no administrator routes and no full-app proxy. */
export async function createWidgetRelay({engine,distDir,avatarHandler,token=randomBytes(20).toString('hex')}) {
  if (!/^[a-f0-9]{40}$/.test(token)) throw new Error('Invalid widget key');
  const prefix='/w/'+token;
  const app=express(),server=createServer(app),wss=new WebSocketServer({noServer:true,maxPayload:1024});
  let publicOrigin='',closing=false;
  app.disable('x-powered-by');
  app.use((_req,res,next)=>{
    res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store',
      'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; media-src 'self' blob:; font-src 'self'; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'none'; form-action 'none'"});
    next();
  });
  const router=express.Router();
  router.use((_req,res,next)=>closing?res.sendStatus(404):next());
  router.get('/health',(_req,res)=>res.json({ok:true,service:'tam-an-widget'}));
  router.get('/overlay',async(_req,res,next)=>{
    try{res.type('html').send(rewriteWidgetHtml(await readFile(path.join(distDir,'index.html'),'utf8'),prefix));}catch(error){next(error);}
  });
  router.get('/api/state',(_req,res)=>res.json(widgetState(engine.getState())));
  router.use('/api/tts',createTtsRouter());
  if(avatarHandler)router.get('/api/avatar/:seed',avatarHandler);
  router.post('/api/ritual/complete',express.json({limit:'512b'}),(req,res)=>{
    const origin=req.get('origin');
    if(origin && origin!==publicOrigin && origin!==`http://${req.get('host')}`)return res.status(403).json({error:'Nguồn yêu cầu không hợp lệ.'});
    res.json({ok:true,completed:engine.completeRitual(String(req.body?.id||''))});
  });
  router.get('/assets/:file',async(req,res,next)=>{
    const name=req.params.file;
    if(!/^[a-zA-Z0-9_-][a-zA-Z0-9_.-]{0,190}$/.test(name)||name.includes('..'))return res.sendStatus(404);
    try{
      const file=path.join(distDir,'assets',name);
      if(name.endsWith('.css'))res.type('css').send((await readFile(file,'utf8')).replaceAll('/assets/',prefix+'/assets/'));
      else res.sendFile(file,error=>{if(error)next(error);});
    }catch(error){next(error);}
  });
  router.get('/audio/:file',(req,res,next)=>{
    if(!['music1.mp3','music2.mp3','REFERENCE-LICENSE.txt'].includes(req.params.file))return res.sendStatus(404);
    res.sendFile(path.join(distDir,'audio',req.params.file),error=>{if(error)next(error);});
  });
  for(const name of ['temple-photo.png','temple.svg','lotus.svg'])router.get('/'+name,(_req,res,next)=>res.sendFile(path.join(distDir,name),error=>{if(error)next(error);}));
  // Explicitly deny all unlisted endpoints, including login, settings, demo and raw files.
  router.use((_req,res)=>res.sendStatus(404));
  app.use(prefix,router);
  app.use((_req,res)=>res.sendStatus(404));
  app.use((_error,_req,res,_next)=>{if(!res.headersSent)res.sendStatus(404);});
  server.on('upgrade',(req,socket,head)=>{
    let url;try{url=new URL(req.url,'http://local');}catch{socket.destroy();return;}
    const origin=req.headers.origin;
    if(closing||url.pathname!==prefix+'/ws'||(origin && origin!==publicOrigin && origin!==`http://${req.headers.host}`)){
      socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');socket.destroy();return;
    }
    wss.handleUpgrade(req,socket,head,client=>wss.emit('connection',client,req));
  });
  const send=(client,data)=>{if(client.readyState===WebSocket.OPEN)client.send(JSON.stringify(data));};
  const state=s=>{for(const client of wss.clients)send(client,{type:'state',state:widgetState(s)});};
  const event=e=>{const output=Object.fromEntries(Object.entries(e).filter(([key])=>['id','type','at','user','text','speech','priority','giftName','count','diamonds','ritualId','effect'].includes(key)));for(const client of wss.clients)send(client,{type:'event',event:output});};
  wss.on('connection',client=>{
    send(client,{type:'state',state:widgetState(engine.getState())});
    client.on('error',()=>{});
    // No inbound commands are supported on the stage connection.
    client.on('message',()=>client.close(1008,'Read-only stage'));
  });
  engine.on('state',state);engine.on('event',event);
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  return {
    port:server.address().port,prefix,
    setPublicOrigin(origin){const u=new URL(origin);if(u.protocol!=='https:')throw new Error('HTTPS required');publicOrigin=u.origin;},
    async close(){closing=true;engine.off('state',state);engine.off('event',event);for(const client of wss.clients)client.terminate();wss.close();const closed=new Promise(resolve=>server.close(resolve));server.closeAllConnections?.();await closed;},
  };
}
