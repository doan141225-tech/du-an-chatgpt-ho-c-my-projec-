import express from 'express';
import { createServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { mkdir, readFile, writeFile, rename } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { LiveEngine } from './engine.js';
import { createTtsRouter } from './tts.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const settingsFile = resolve(root, '.local/settings.json');
let savedSettings = {};
try { savedSettings = JSON.parse(await readFile(settingsFile, 'utf8')); } catch (error) { if (error.code !== 'ENOENT') console.warn('Không đọc được cài đặt đã lưu, đang dùng mặc định.'); }
export const engine = new LiveEngine(savedSettings);
export const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
const http = createServer(app);
const wss = new WebSocketServer({ server: http, path: '/ws' });

function send(socket, payload) {
  if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
}
function broadcast(payload) { for (const socket of wss.clients) send(socket, payload); }
wss.on('connection', (socket) => {
  send(socket, { type: 'state', state: engine.getState() });
  socket.on('error', () => {});
});
engine.on('state', state => broadcast({ type: 'state', state }));
engine.on('event', event => broadcast({ type: 'event', event }));

// The dashboard and overlay are served from the same origin. Restrict mutation
// routes to same-origin browser requests while allowing local automation.
app.use('/api', (req, res, next) => {
  const origin = req.get('origin');
  if (req.method !== 'GET' && origin) {
    try {
      if (new URL(origin).host !== req.get('host')) return res.status(403).json({ error: 'Yêu cầu phải đến từ trang điều khiển này.' });
    } catch { return res.status(403).json({ error: 'Nguồn yêu cầu không hợp lệ.' }); }
  }
  next();
});

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'tam-an-lanh', mode: engine.connection.status }));
app.get('/api/state', (_req, res) => res.json(engine.getState()));
app.get('/api/settings', (_req, res) => res.json(engine.settings));
app.use('/api/tts', createTtsRouter());
let saveChain = Promise.resolve();
function saveSettings() {
  const body = JSON.stringify(engine.settings, null, 2);
  saveChain = saveChain.catch(() => {}).then(async () => {
    await mkdir(dirname(settingsFile), { recursive: true });
    await writeFile(settingsFile + '.tmp', body, { mode: 0o600 });
    await rename(settingsFile + '.tmp', settingsFile);
  });
  return saveChain;
}
app.post('/api/settings', async (req, res, next) => {
  try {
    engine.setSettings(req.body || {});
    await saveSettings();
    res.json({ ok: true, state: engine.getState() });
  } catch (error) { next(error); }
});

const requests = new Map();
function limitMutation(req, res, next) {
  const key = req.ip;
  const now = Date.now();
  const entry = requests.get(key);
  if (!entry || now > entry.until) requests.set(key, { count: 1, until: now + 1000 });
  else if (++entry.count > 30) return res.status(429).json({ error: 'Thao tác quá nhanh, vui lòng chờ một chút.' });
  next();
}
app.post('/api/demo', limitMutation, (req, res, next) => {
  try {
    if (engine.connection.status === 'connected') return res.status(409).json({ error: 'Hãy ngắt kết nối LIVE trước khi gửi sự kiện trải nghiệm.' });
    const event = engine.handle(req.body || {});
    res.json({ ok: true, event, state: engine.getState() });
  } catch (error) { next(error); }
});
app.post('/api/speak', limitMutation, (req, res, next) => {
  try { const event = engine.speak(req.body?.text); res.json({ ok: true, event }); } catch (error) { next(error); }
});
app.post('/api/ritual/complete', limitMutation, (req, res) => {
  const completed = engine.completeRitual(String(req.body?.id || ''));
  res.json({ ok: true, completed });
});
app.post('/api/reset', (_req, res) => {
  if (engine.connection.status === 'connected' || engine.connection.status === 'connecting') return res.status(409).json({ error: 'Hãy ngắt kết nối trước khi đặt lại phiên.' });
  engine.reset(); res.json({ ok: true, state: engine.getState() });
});

let connector = null;
let connectGeneration = 0;
async function disconnect() {
  connectGeneration += 1;
  if (connector) {
    connector.removeAllListeners();
    try { connector.disconnect(); } catch {}
    connector = null;
  }
}
app.post('/api/disconnect', async (_req, res) => {
  await disconnect();
  engine.setConnection(engine.settings.demoMode ? 'demo' : 'disconnected', engine.settings.demoMode ? 'Đang chạy chế độ trải nghiệm' : 'Đã ngắt kết nối TikTok LIVE');
  res.json({ ok: true, state: engine.getState() });
});
app.post('/api/connect', async (req, res) => {
  const username = String(req.body?.username || engine.settings.tiktokUsername || '').replace(/^@/, '').trim();
  if (!/^[a-zA-Z0-9_.]{2,64}$/.test(username)) return res.status(400).json({ error: 'Nhập tên TikTok hợp lệ, ví dụ @tamanlanh.' });
  await disconnect();
  const generation = ++connectGeneration;
  engine.setSettings({ tiktokUsername: username, demoMode: false });
  engine.setConnection('connecting', `Đang kết nối @${username}…`);
  await saveSettings().catch(() => {});
  try {
    const module = await import('tiktok-live-connector');
    if (generation !== connectGeneration) return res.status(409).json({ error: 'Yêu cầu kết nối đã được hủy.' });
    const Connection = module.TikTokLiveConnection || module.WebcastPushConnection;
    if (!Connection) throw new Error('Phiên bản thư viện kết nối chưa được hỗ trợ.');
    const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
    let proxyOptions = {};
    if (proxy) {
      const { HttpProxyAgent, HttpsProxyAgent } = await import('hpagent');
      proxyOptions = {
        webClientOptions: { timeout: { request: 15000 }, agent: { http: new HttpProxyAgent({ proxy, keepAlive: true }), https: new HttpsProxyAgent({ proxy, keepAlive: true }) } },
        wsClientOptions: { agent: new HttpsProxyAgent({ proxy, keepAlive: true }) },
      };
    }
    const current = new Connection(username, { processInitialData: false, enableExtendedGiftInfo: true, ...proxyOptions });
    connector = current;
    const receive = action => data => { if (generation === connectGeneration) { try { action(data); } catch { console.warn('Đã bỏ qua một sự kiện TikTok không hợp lệ.'); } } };
    current.on('member', receive(data => engine.handle({ type: 'join', user: data })));
    current.on('chat', receive(data => engine.handle({ type: 'comment', user: data, text: data.comment })));
    current.on('gift', receive(data => engine.handleTikTokGift(data)));
    current.on('like', receive(data => engine.handle({ type: 'like', user: data, count: data.likeCount })));
    current.on('roomUser', data => {
      if (generation !== connectGeneration) return;
      engine.setViewerCount(data.viewerCount);
    });
    current.on('disconnected', () => { if (generation === connectGeneration) engine.setConnection('disconnected', 'Kết nối LIVE đã đóng. Bạn có thể kết nối lại.'); });
    current.on('streamEnd', () => { if (generation === connectGeneration) engine.setConnection('disconnected', 'Phiên TikTok LIVE đã kết thúc.'); });
    current.on('error', () => { if (generation === connectGeneration) engine.setConnection('error', 'Không nhận được dữ liệu TikTok. Kiểm tra tài khoản đang LIVE rồi kết nối lại.'); });
    let timeout;
    try {
      await Promise.race([current.connect(), new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('Kết nối TikTok hết thời gian chờ.')), 25000); })]);
    } finally { clearTimeout(timeout); }
    if (generation !== connectGeneration) { try { current.disconnect(); } catch {} return res.status(409).json({ error: 'Yêu cầu kết nối đã được hủy.' }); }
    // Starting a real stream clears the explicitly marked demo occupants.
    engine.reset();
    engine.setConnection('connected', `Đang nhận sự kiện từ @${username}`);
    res.json({ ok: true, state: engine.getState() });
  } catch (error) {
    if (generation === connectGeneration) {
      await disconnect();
      engine.setConnection('error', 'Chưa kết nối được TikTok. Hãy kiểm tra tài khoản đang LIVE, quyền truy cập mạng và thử lại.');
    }
    console.warn('TikTok connection failed:', String(error?.name || 'ConnectionError').slice(0, 80));
    res.status(502).json({ error: engine.connection.message, state: engine.getState() });
  }
});

function xml(value) { return String(value).replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c])); }
app.get('/api/avatar/:seed', (req, res) => {
  const names = String(req.query.name || req.params.seed).trim().split(/\s+/);
  const initials = names.slice(-2).map(part => part[0]).join('').toUpperCase();
  let hash = 0; for (const c of req.params.seed) hash = ((hash << 5) - hash + c.charCodeAt(0)) | 0;
  const colors = [['#acc6b7', '#425b4a'], ['#d9bfa5', '#8f634b'], ['#bac9d6', '#526779'], ['#c8b6c7', '#765b73'], ['#d7cd9e', '#7e7147']];
  const [bg, fg] = colors[Math.abs(hash) % colors.length];
  res.type('image/svg+xml').set('Cache-Control', 'public, max-age=86400').send(`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" rx="48" fill="${bg}"/><circle cx="48" cy="34" r="18" fill="${fg}" opacity=".35"/><path d="M13 96v-6a35 35 0 0 1 70 0v6" fill="${fg}" opacity=".35"/><text x="48" y="67" font-family="sans-serif" font-size="26" text-anchor="middle" font-weight="600" fill="white">${xml(initials)}</text></svg>`);
});

// Optional static production build; Vite proxies these routes during development.
app.use(express.static(resolve(root, 'dist')));
app.get(/^(?!\/api(?:\/|$)).*/, (_req, res, next) => res.sendFile(resolve(root, 'dist/index.html'), error => error && next()));
app.use((error, _req, res, _next) => {
  res.status(error.status || 400).json({ error: error.type === 'entity.too.large' ? 'Nội dung vượt quá giới hạn.' : String(error.message || 'Không xử lý được yêu cầu.').slice(0, 250) });
});
const idleTimer = setInterval(() => engine.idleTick(), 15000);
idleTimer.unref();
setInterval(() => { const now = Date.now(); for (const [key, value] of requests) if (value.until < now) requests.delete(key); }, 60000).unref();

const port = Number(process.env.PORT) || 3001;
const host = process.env.HOST || '0.0.0.0';
http.listen(port, host, () => console.log(`Tâm An Lành API listening on ${host}:${port}`));
async function shutdown() { clearInterval(idleTimer); await disconnect(); wss.close(); http.close(() => process.exit(0)); setTimeout(() => process.exit(0), 2000).unref(); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
