export const EDGE_VOICES = ['vi-VN-NamMinhNeural', 'vi-VN-HoaiMyNeural'];
export const AUDIO_PRESET = Object.freeze({
  voiceEngine: 'edge', voice: 'vi-VN-NamMinhNeural', pitch: -18,
  rate: 0.8, commentRate: 0.9, voiceFallback: true, browserVoice: '',
  musicEnabled: true, musicVolume: 0.45, musicMode: 'cycle',
  musicDuck: true, musicDuckLevel: 0.28, musicCrossfade: 4,
  moEnabled: true, moBpm: 52, sfxVolume: 0.4, bellEnabled: true,
  autoChant: true, chantEverySec: 25,
});
export const CHANTS = [
  'Nam mô Bổn Sư Thích Ca Mâu Ni Phật. Nguyện đem công đức này, hướng về khắp tất cả, đệ tử và chúng sinh, đều trọn thành Phật đạo.',
  'Nam mô A Di Đà Phật. Nguyện sanh Tây Phương Tịnh Độ trung, cửu phẩm liên hoa vi phụ mẫu.',
  'Nam mô Đại Bi Quán Thế Âm Bồ Tát. Nguyện cho tất cả chúng sinh thân tâm an lạc, tai qua nạn khỏi.',
  'Quán Tự Tại Bồ Tát hành thâm Bát Nhã Ba La Mật Đa thời, chiếu kiến ngũ uẩn giai không, độ nhất thiết khổ ách.',
];
