// Portable launcher. No administrator permissions or changes to Windows are needed.
const { spawn } = require('node:child_process');
const { existsSync } = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const port = Number(process.env.TAM_AN_PORT || 3001);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('TAM_AN_PORT phai la so tu 1024 den 65535.');
const dashboard = `http://127.0.0.1:${port}`;
const noOpen = process.argv.includes('--no-open');
const expectedVersion = require(path.join(root, 'package.json')).version;
let child;
let stopping = false;

function openBrowser() {
  if (noOpen || process.platform !== 'win32') return;
  const systemRoot = process.env.SystemRoot || 'C:\\Windows';
  const opener = spawn(path.join(systemRoot, 'System32', 'rundll32.exe'), ['url.dll,FileProtocolHandler', dashboard], { windowsHide: true, stdio: 'ignore' });
  opener.on('error', () => console.log(`Mo Edge/Chrome va vao: ${dashboard}`));
  opener.unref();
}

async function health() {
  try {
    const response = await fetch(`${dashboard}/api/health`, { signal: AbortSignal.timeout(800) });
    if (!response.ok) return { occupied: true };
    const result = await response.json();
    return result.ok && result.service === 'tam-an-lanh' ? { ready: true, version: result.version } : { occupied: true };
  } catch (error) {
    return error instanceof SyntaxError ? { occupied: true } : {};
  }
}

function stop() {
  if (stopping) return;
  stopping = true;
  if (child && child.exitCode === null) child.kill();
}
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

async function main() {
  console.log('\n  TAM AN - TIKTOK LIVE STUDIO\n');
  for (const file of ['dist/index.html', 'server/index.js', 'node_modules/express/package.json']) {
    if (!existsSync(path.join(root, file))) throw new Error(`Thieu ${file}. Giai nen TOAN BO file ZIP truoc khi chay. Voi ma nguon, chay npm ci va npm run build.`);
  }
  const current = await health();
  if (current.ready && current.version !== expectedVersion) throw new Error('Phien ban cu dang chay. Dong cua so den cu (Ctrl+C), roi mo lai Khoi-dong.bat cua ban moi.');
  if (current.ready) {
    console.log(`Ung dung da chay. Mo trang dieu khien: ${dashboard}`);
    openBrowser();
    return;
  }
  if (current.occupied) throw new Error(`Cong ${port} dang duoc ung dung khac su dung. Khong tu dong dung ung dung khac.`);

  child = spawn(process.execPath, [path.join(root, 'server/index.js')], {
    cwd: root, env: { ...process.env, HOST: '127.0.0.1', PORT: String(port) },
    stdio: 'inherit', windowsHide: true,
  });
  let childError;
  child.on('error', error => { childError = error; });
  child.on('exit', code => {
    if (!stopping && code) console.error(`May chu dung voi ma loi ${code}. Xem thong bao o tren.`);
    if (code) process.exitCode = 1;
  });

  for (let attempt = 0; attempt < 40; attempt++) {
    if (childError) throw childError;
    if (child.exitCode !== null) throw new Error('May chu khong khoi dong duoc. Xem noi dung loi o tren.');
    if ((await health()).ready) {
      console.log(`\nTrang dieu khien: ${dashboard}`);
      console.log('LIVE Studio: vao muc Link LIVE Studio tren trang dieu khien, bam Tao link HTTPS.');
      console.log('Giu cua so nay khi phat live. Bam Ctrl+C de dung.\n');
      const voice = await fetch(`${dashboard}/api/tts/status`).then(r => r.json()).catch(() => ({}));
      if (!voice.available) console.log('Giong doc cuc bo chua san sang. Thu giong Viet trong Edge/Chrome hoac xem HUONG-DAN-WINDOWS.html.');
      openBrowser();
      return;
    }
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  throw new Error('Het thoi gian cho may chu khoi dong. Xem noi dung loi o tren.');
}

main().catch(error => {
  console.error(`\nKhong khoi dong duoc: ${error.message}`);
  stop();
  process.exitCode = 1;
});
