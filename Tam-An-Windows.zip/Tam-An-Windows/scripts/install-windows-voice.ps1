# Optional source-checkout helper. The portable Windows ZIP already includes this voice.
# Administrative MSI extraction creates a private image; it does not install/register SAPI globally.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$repositoryRoot = Split-Path -Parent $PSScriptRoot
$destination = Join-Path $repositoryRoot '.local\tts-windows'
$binary = Join-Path $destination 'espeak-ng.exe'
$expectedHash = '7f673c709ea5dd579d3b5ebb98688cc575328a6ab7438d2bc405b88cedaeafb9'
$releaseUrl = 'https://github.com/espeak-ng/espeak-ng/releases/download/1.52.0/espeak-ng.msi'
if (-not [Environment]::Is64BitOperatingSystem) {
    throw 'The offline Vietnamese voice requires 64-bit Windows.'
}
if (-not (Test-Path -LiteralPath $binary)) {
    $work = Join-Path $repositoryRoot '.local\voice-download'
    $image = Join-Path $work 'image'
    New-Item -ItemType Directory -Force -Path $work, $image | Out-Null
    $installer = Join-Path $work 'espeak-ng-1.52.0.msi'
    if (-not (Test-Path -LiteralPath $installer)) {
        Write-Host 'Downloading official offline Vietnamese voice...'
        Invoke-WebRequest -UseBasicParsing -Uri $releaseUrl -OutFile $installer
    }
    $actualHash = (Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) {
        Remove-Item -LiteralPath $installer -Force
        throw 'eSpeak package checksum did not match. No downloaded binary was executed.'
    }
    $log = Join-Path $work 'extract.log'
    $arguments = @('/a', ('"' + $installer + '"'), '/qn', ('TARGETDIR="' + $image + '"'), '/L*V', ('"' + $log + '"'))
    $extraction = Start-Process -FilePath 'msiexec.exe' -ArgumentList $arguments -Wait -PassThru -WindowStyle Hidden
    if ($extraction.ExitCode -ne 0) {
        throw ('Could not extract local speech files. MSI exit code: ' + $extraction.ExitCode + '. See ' + $log)
    }
    $extracted = Get-ChildItem -LiteralPath $image -Filter 'espeak-ng.exe' -Recurse | Select-Object -First 1
    if ($null -eq $extracted) { throw 'Official speech package did not contain espeak-ng.exe.' }
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Copy-Item -LiteralPath (Join-Path $extracted.DirectoryName 'espeak-ng.exe') -Destination $destination -Force
    Copy-Item -LiteralPath (Join-Path $extracted.DirectoryName 'libespeak-ng.dll') -Destination $destination -Force
    Copy-Item -LiteralPath (Join-Path $extracted.DirectoryName 'espeak-ng-data') -Destination $destination -Force -Recurse
}
try {
    $voices = & $binary ('--path=' + $destination) '--voices=vi' 2>&1
    if ($LASTEXITCODE -ne 0 -or ($voices -join "`n") -notmatch 'Vietnamese') {
        throw 'Voice probe failed.'
    }
    Write-Host 'Offline Vietnamese voice is available.'
} catch {
    throw 'The offline voice could not start. If Microsoft Visual C++ x64 Runtime is missing, install the official runtime from https://aka.ms/vs/17/release/vc_redist.x64.exe and retry. A Vietnamese browser voice can also be used.'
}
