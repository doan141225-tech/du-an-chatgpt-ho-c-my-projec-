# Tâm An · Live Studio

Ứng dụng livestream dâng hương theo ảnh và video tham chiếu, gồm trang điều khiển và sân khấu dọc 9:16 dùng với TikTok LIVE Studio hoặc OBS. Tài khoản mặc định: **@yahyah_155**. Tên kênh có thể thay đổi trong Cài đặt kênh.

## Chạy ứng dụng

**Windows 10/11 64-bit:** tải bản `Tam-An-Windows.zip`, chọn **Extract All / Giải nén tất cả**, rồi mở `Khoi-dong.bat`. Bản portable có sẵn Node.js, thư viện production, giao diện đã build và giọng Việt eSpeak dự phòng; không cần tự cài Node, npm hoặc OBS. Giữ nguyên toàn bộ thư mục đã giải nén và giữ cửa sổ khởi động khi phát live. Trình duyệt sẽ mở sau khi máy chủ sẵn sàng.

Mở `HUONG-DAN-WINDOWS.html` để xem hướng dẫn có hình thức dễ đọc. Bộ khởi động chỉ lắng nghe trên `127.0.0.1`, không thay đổi cài đặt hệ thống. Nếu bộ giọng eSpeak thiếu Microsoft Visual C++ x64 Runtime, hướng dẫn có đường dẫn bộ cài chính thức và cách thử lại.

**Chạy từ mã nguồn:** cần Node.js 24 LTS và npm, sau đó chạy:

```bash
npm ci
npm run dev
```

Mở trang điều khiển tại `http://localhost:5173`. Vite chuyển tiếp API/WebSocket đến máy chủ ở cổng 3001.

Chạy bản production:

```bash
npm run build
npm start
```

Trang điều khiển production: `http://localhost:3001`. Sân khấu riêng: `/overlay?audio=1`.

## Đưa lên TikTok LIVE Studio

1. Chạy `Khoi-dong.bat` và thử một quà ở trang điều khiển.
2. Trong **Cài đặt kênh → Hiển thị & phát sóng**, bấm **Mở cửa sổ sân khấu**. Cửa sổ này có tiêu đề **Tâm An · Sân khấu LIVE** và phát âm thanh; trang điều khiển tự tắt tiếng để tránh đọc trùng.
3. Trong TikTok LIVE Studio, thêm **Liên kết / Link / Browser** nếu phiên bản của bạn có nguồn này; dán `http://127.0.0.1:3001/overlay?audio=1`, đặt 1080 × 1920.
4. Nếu không có nguồn Link/Browser, mở sân khấu trong Edge/Chrome rồi thêm **Chụp cửa sổ / Window Capture**, chọn đúng cửa sổ sân khấu. Cắt phần thanh trình duyệt nếu cần; có thể dùng F11 khi cửa sổ sân khấu được chọn.
5. Với chụp cửa sổ, bật **Âm thanh hệ thống / System Audio** trong LIVE Studio. Chỉ lấy âm thanh một lần; không thu lại bằng micro hoặc mở hai sân khấu cùng phát tiếng. Với nguồn Link, dùng âm thanh của nguồn đó nếu có.
6. Bắt đầu LIVE trên TikTok LIVE Studio, sau đó quay lại trang điều khiển và bấm **Kết nối** với `yahyah_155` để nhận bình luận, tim và quà thật.

Tên nguồn và khả năng thêm liên kết có thể thay đổi theo phiên bản LIVE Studio. Không cần cài OBS cho phương án chụp cửa sổ.

## Đưa lên OBS

1. Bấm **Lấy link phát live** trên trang điều khiển.
2. Trong OBS, thêm nguồn **Browser Source / Trình duyệt**, dán link và đặt **1080 × 1920**.
3. Bật **Control audio via OBS / Điều khiển âm thanh qua OBS**.
4. Tắt biểu tượng loa trên trang điều khiển nếu đang dùng âm thanh nguồn OBS để tránh đọc hai lần.
5. Chỉ giữ một nguồn sân khấu có âm thanh. Với tab xem trước phụ, dùng `/overlay` không có `audio=1`.

Trình duyệt có thể yêu cầu một lần bấm **Bật âm thanh** trước khi cho phát giọng đọc. Trong OBS, dùng chức năng **Interact / Tương tác** để bấm biểu tượng loa ở góc dưới sân khấu nếu cần.

## Tính năng

- Điện thờ vàng, nền được tạo theo video tham chiếu; nhân vật và hiệu ứng chạy bằng Three.js/WebGL.
- Người xem có tên và avatar riêng, chỗ ngồi, hàng đợi dâng hương.
- Bình luận `adidaphat` hoặc `A Di Đà Phật`: nhân vật tiến lên, dâng hương, lạy ba lạy và về chỗ. Mỗi lượt khoảng 16,5 giây.
- Quà tặng: thẻ tên và avatar, camera theo nhân vật, sen vàng nở, cánh sen hồng bay. Combo quà chỉ được ghi nhận một lần sau khi kết thúc.
- Cứ đủ 666 tim: mưa sen 60 giây. Đạt ngưỡng mới trong lúc đang mưa sẽ bắt đầu lại thời gian 60 giây.
- TOP thành tâm: 1 điểm/bình luận, 10 điểm/xu quà tặng.
- Giọng Việt gọi tên người tặng quà, dùng 12 lời chúc luân phiên; nhận biết nhóm mong cầu thi cử, sức khỏe, tình duyên, gia đình, công việc và bình an.
- Hàng đọc ưu tiên **quà → câu nhập tay → bình luận → lời chào → lời chúc khi yên lặng**. Không ngắt câu đang đọc. Các sự kiện được đưa thẳng vào hàng đọc để không bị gộp mất khi nhận nhiều tương tác cùng lúc.
- Sau 90 giây không có tương tác, tự gửi lời chúc và mời chia sẻ; có thể tắt trong cài đặt.
- Gõ tối đa 500 ký tự, bấm **Đọc ngay**; đổi tên kênh để giọng đọc xưng đúng tên.
- Chế độ demo độc lập, giao diện điện thoại, mở rộng sân khấu và xuất OBS.

## Giọng đọc tiếng Việt

Bản 1.1 dùng cùng bộ đọc **Microsoft Edge Nam Minh Neural** như file Chánh Điện V5 người dùng cung cấp. Nút **Giống file mẫu** đặt Nam Minh, pitch −18 Hz, thông báo/quà −20%, bình luận −10%, nhạc luân phiên, mõ 52 BPM và tụng kinh mỗi 25 giây. Có thể đổi sang **Hoài My**, bộ đọc trình duyệt hoặc **espeak-ng ngoại tuyến**. Giọng cục bộ có chất giọng máy, không phải giọng tự nhiên.

Trong mục **Giọng đọc & nhạc**, chỉnh riêng âm lượng giọng, âm lượng nhạc, độ trầm/cao, tốc độ thông báo và bình luận; chọn/lặp bài, thời gian chuyển bài, mức hạ nhạc khi đang đọc; bật/tắt mõ, chuông, tụng kinh và chỉnh nhịp/âm lượng/khoảng cách. Mọi thay đổi lưu vào `.local/settings.json`, đồng bộ sang cửa sổ live. Khi chuyển giọng hoặc tốc độ, câu đang đọc vẫn được đọc hết; cấu hình mới áp dụng từ câu tiếp theo.

Hai bài `Trăng trên rừng trúc` và `Hơi thở ban mai` được lấy nguyên MP3 từ file người dùng cung cấp, đi kèm giấy phép trong `public/audio/REFERENCE-LICENSE.txt`. Nhạc tự luân phiên, chuyển bài êm và tự hạ xuống mức cài đặt khi có giọng đọc, rồi trở lại sau câu đọc. Chuông và mõ được tổng hợp bằng Web Audio theo file mẫu.

Giọng Microsoft Edge cần Internet và dịch vụ Read Aloud hoạt động. Thử thật trong cloud bị proxy từ chối CONNECT403 tại `speech.platform.bing.com`; không mô tả âm thanh Nam Minh đã được nghe/kiểm thử thành công ở đây. Trên Windows, ứng dụng kết nối qua Internet của máy bạn. Nếu có lỗi, giao diện báo rõ và chỉ chuyển sang bộ dự phòng khi **Tự dùng giọng dự phòng** được bật; có thể tắt tùy chọn này để giữ đúng giọng được chọn.

Trong môi trường cloud này, espeak-ng đã được cài tại `.local/tts` và đã thử trả âm thanh WAV thật. Với Debian/Linux amd64:

```bash
bash scripts/install-tts.sh
```

Script tải gói Debian qua metadata có chữ ký và checksum, giải nén vào `.local/tts`, không cần sửa gói hệ thống. Máy khác có thể cài `espeak-ng` bằng trình quản lý gói của hệ điều hành. Bản Windows portable đã kèm eSpeak NG x64 và dữ liệu tiếng Việt. Nếu tải riêng mã nguồn, dùng trình duyệt có giọng Việt, cài espeak-ng vào PATH hoặc dùng `scripts/install-windows-voice.ps1` (tải MSI chính thức, kiểm tra SHA256 và giải nén cục bộ). Không đổi chính sách thực thi PowerShell để ép chạy nếu máy tổ chức chặn script.

Kiểm tra giọng dự phòng qua `/api/tts/status`.

## Kết nối TikTok thật

Bắt đầu LIVE trên tài khoản, nhập `yahyah_155` vào ô kết nối rồi bấm **Kết nối**. Ứng dụng chỉ hiển thị **Đã kết nối** sau khi thư viện nhận được phòng LIVE; chế độ demo luôn có nhãn **DEMO**.

Kết nối dùng thư viện cộng đồng `tiktok-live-connector`, phụ thuộc khả năng truy cập TikTok và dịch vụ ký của thư viện. Đây không phải API LIVE chính thức; trạng thái LIVE, hạn mức, vùng và thay đổi từ TikTok có thể ảnh hưởng. Không cần đưa mật khẩu TikTok vào ứng dụng.

**Kết quả kiểm tra trong cloud:** proxy trả 403 cho `www.tiktok.com`, `webcast.tiktok.com`, `api.eulerstream.com`; vì vậy chưa xác minh kết nối LIVE của @yahyah_155. Ba miền đã được lưu vào bản nháp cấu hình mạng. Cần xem lại, lưu thay đổi trong cài đặt môi trường và Publish, sau đó thử kết nối lại. Tên miền WebSocket/avatar thực tế có thể cần bổ sung theo phản hồi khi kết nối được.

**Bản Windows chạy trực tiếp bằng Internet của máy bạn**, không cần Publish cấu hình cloud để dùng tại nhà. Lỗi proxy nêu trên là kết quả trong cloud, không chứng minh máy Windows của bạn cũng bị chặn. Cần thử khi tài khoản đang LIVE.

Không dùng sự kiện demo để khẳng định phiên LIVE thật đã hoạt động. Giới hạn mạng này không ảnh hưởng các nút thử, sân khấu hoặc giọng đọc ngoại tuyến.

## Kiểm thử

```bash
npm test             # 21 kiểm thử cấu hình, PIN, sự kiện, giọng và nghi lễ
npm run build       # TypeScript + production build
node scripts/check-ui.mjs  # Chạy khi npm run dev đang hoạt động
node scripts/check-audio.mjs # Nhạc MP3 thật, ducking, crossfade và lưu cài đặt
```

Kiểm thử giao diện dùng Chromium tại `/usr/bin/chromium`; đặt `CHROMIUM_PATH` nếu máy dùng đường dẫn khác. `STUDIO_URL` cho phép đổi địa chỉ ứng dụng. Chỉ chạy kiểm thử trên phiên demo vì kiểm thử gửi tương tác thử. Giọng trình duyệt trong bài kiểm thử được mô phỏng để kiểm tra thứ tự; âm thanh WAV dự phòng được tạo và kiểm tra thật.

Đã kiểm tra thêm nghi lễ ba lạy, camera theo quà, mưa sen và nguồn OBS. Không dùng số lượng kiểm thử logic để suy ra kết nối LIVE thật đã đạt.

## Dữ liệu và vận hành

- Cài đặt lưu tại `.local/settings.json`, không đưa vào Git.
- Danh sách người xem, điểm phiên, hàng đợi và lịch sử tương tác lưu trong RAM: khởi động lại máy chủ sẽ bắt đầu phiên mới. Đây chưa phải hệ thống lưu trữ lịch sử dài hạn.
- Demo có tám người và điểm mẫu để xem bố cục, tách biệt với nhãn LIVE thật. Khi kết nối LIVE thành công, người mẫu được xóa.
- Tối đa 28 người ngồi được vẽ cùng lúc để giữ hiệu năng. Người đang dâng hương vẫn được đưa lên sân khấu dù ngoài nhóm này; máy chủ ghi nhận mọi người vào phòng.
- Nếu mở nhiều cửa sổ studio/overlay, máy chủ chỉ tính hoàn thành mỗi lượt một lần.
- Ứng dụng điều khiển local. Nếu đưa ra Internet, cần đặt sau xác thực và HTTPS; không công khai trang điều khiển không có bảo vệ.

## Bố cục mã

- `src/App.tsx`: trang điều khiển, bảng thành tâm, cài đặt và overlay OBS.
- `src/useStudio.ts`: WebSocket, hàng đợi giọng đọc và dự phòng âm thanh.
- `src/components/TempleScene.tsx`: nhân vật 3D, nghi lễ, camera và hiệu ứng.
- `server/engine.js`: sự kiện, điểm, lời chúc, hàng đợi và chế độ demo.
- `server/index.js`: API, WebSocket và kết nối TikTok.
- `server/tts.js`: giọng Việt ngoại tuyến.
- `public/temple-photo.png`: nền điện thờ tạo theo video người dùng cung cấp; `temple.svg` là nền vector dự phòng.

## Đóng gói Windows

`scripts/package-windows.py` tạo bản portable từ Node.js Windows x64 chính thức đã kiểm tra SHA256, `npm ci --omit=dev --os=win32 --cpu=x64` trong thư mục staging, bản production `dist` và bộ eSpeak Windows. Chỉ sao chép thành phần cần chạy, không đưa `.local/settings.json`, Git metadata hoặc dữ liệu phiên vào bản tải. eSpeak đi kèm giấy phép GPL, thông tin nguồn gốc và mã nguồn tương ứng.

Đã kiểm tra checksum, định dạng PE của các tệp Windows, thành phần gói, quy trình khởi động máy chủ và giao diện trên Linux. **Chưa thực thi trực tiếp trên Windows thật hoặc máy của người dùng.** Không mô tả bản portable đã được cài trên máy người dùng.

## Cập nhật từ bản Windows 1.0

Đóng cửa sổ chạy màu đen của bản cũ (Ctrl+C), đóng cửa sổ sân khấu cũ, giải nén bộ 1.1 vào thư mục mới rồi mở `Khoi-dong.bat`. Bộ chạy không tự tắt tiến trình khác; nếu phát hiện bản cũ còn dùng cổng3001 sẽ báo để bạn đóng bản cũ. Muốn giữ tên kênh/tùy chọn cũ có thể sao chép `.local/settings.json` sang thư mục mới trước khi chạy, sau đó bấm **Giống file mẫu** để áp dụng các thiết lập âm thanh mới.

Trong nguồn Browser của LIVE Studio, có thể cần bấm **Bật âm thanh** một lần qua chức năng tương tác. Khi chụp cửa sổ Edge/Chrome, bấm nút này ngay trong cửa sổ sân khấu rồi kiểm tra âm lượng System Audio.

## Quản trị nâng cao · bản1.2

Mục **Quản trị nâng cao** gồm:

- **Nghi lễ:** bật/tắt dâng hương từ comment/quà; từ khóa riêng; tốc độ đi lên và về chỗ0,25–4×; thời gian dâng hương; số lần lạy0–108, thời gian mỗi lạy và độ cúi. Có tổng thời gian dự kiến, kết thúc lượt và xóa hàng đợi. Cấu hình nghi lễ được chụp riêng cho mỗi lượt khi xếp hàng, để đổi cài đặt không làm hỏng lượt đang chạy.
- **Lời chúc:** sửa kho lời chúc, chọn ngẫu nhiên/đọc tuần tự; mẫu cảm ơn quà, lời chào, dâng hương, comment, lời chúc khi yên lặng và mưa sen; sửa sáu lời chúc theo mong cầu và nội dung tụng kinh. Dùng `{kenh}`,`{ten}`,`{qua}`,`{soluong}`,`{binhluan}`,`{loichuc}` để tự điền nội dung. Câu phát âm thanh tối đa500ký tự.
- **Giao diện:** sửa tiêu đề sân khấu, nhãn quà, tên bảng TOP, dòng thương hiệu; kích thước/số nhân vật, độ sáng, thời gian thẻ quà, camera theo người tặng, sen vàng, số/tốc độ cánh sen; bật/tắt riêng từng thành phần.
- **Tương tác:** đổi ngưỡng tim và thời gian mưa sen, điểm comment/xu quà và khoảng yên lặng trước lời chúc. Điểm hiện tại được tính lại khi đổi hệ số.
- **Bảo vệ & sao lưu:** mãPIN quản trị tùy chọn; xuất toàn bộ cấu hìnhJSON, nhập vào bản chỉnh sửa rồi bấm **Lưu toàn bộ**. PIN không nằm trong tệpJSON.

Âm thanh1.1 vẫn được giữ trong mục **Giọng đọc & nhạc**. Các thay đổi quản trị áp dụng sau khi bấm **Lưu toàn bộ**, lưu trên máy và đồng bộ sang màn hìnhlive.

Khi đặt PIN4–12chữ số, API thay đổi cấu hình yêu cầu phiên quản trị; PIN được băm cósalt trong `.local/admin-auth.json`, cookieHttpOnly/SameSiteStrict, phiên8giờ. Sân khấu công khai vẫn đọc trạng thái và báo hoàn thành nghi lễ; không được sửa cài đặt. Chạy trên Windows cá nhân vẫn dùng127.0.0.1. Không có PIN mặc định hoặc mật khẩu được gửi trong chat.

Nếu quên PIN trên chính máy của bạn: đóng ứng dụng, sao lưu rồi xóa `.local/admin-auth.json` trong thư mục ứng dụng để đặt lại. Không xóa `.local/settings.json` nếu muốn giữ cấu hình. TệpPIN và cài đặt riêng không được đưa vào bộZIPphân phối.

Kiểm tra bổ sung: `node scripts/check-admin.mjs` (máy chủdemo đang chạy). Bài kiểm tra thay đổi cấu hình tạm thời, kiểm tra2lạy thật, ngưỡng tim/thời gian mưa, lời chúc, xuất/nhậpJSON, bố cụcđiện thoại; PIN được kiểm tra bằng máy chủ và tệp tạm riêng, không thay đổi PIN của người dùng. Không chạy các bàiUI/âm thanh/admin song song vì cùng sửa cài đặt phiên thử.
