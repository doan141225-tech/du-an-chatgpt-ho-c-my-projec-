eSpeak NG 1.52.0, official Windows x64 build.

The complete upstream source archive is in source/, and GPL license text is in COPYING.
PROVENANCE.json records the official URLs, source/package hashes, and extracted file hashes.

This directory is private to Tam An; no SAPI registration or system installation is performed.
Required native dependencies: Microsoft Visual C++ x64 Runtime (VCRUNTIME140.dll, VCRUNTIME140_1.dll, MSVCP140.dll) and Windows Universal CRT.
If missing, use the official Microsoft runtime installer: https://aka.ms/vs/17/release/vc_redist.x64.exe

Windows execution has not been tested in the Linux development environment.
